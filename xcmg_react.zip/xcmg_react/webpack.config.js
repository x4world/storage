const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const watch = true;
//const mode = 'development';
const mode = 'production';
const _module = {
	rules: [{ 
		test: /\.less$/,
		use: [
			MiniCssExtractPlugin.loader,
			{
				loader: 'css-loader',
				options: {
					modules: {
						localIdentName:'[hash:base64:6]'
					}
				}
			},
			'less-loader'
		]
	}, { 
		test: /\.css$/, 
		use: [
			MiniCssExtractPlugin.loader,
			'css-loader'
		]
	}, {
		test: /\.(woff|woff2|eot|ttf|svg)$/,
		loader: 'url-loader?limit=100000'
	}, {
		test: /\.js$/,
		exclude: /node_modules/,
		use: {
			loader: 'babel-loader',
			options: {
				presets: ['@babel/preset-env', '@babel/preset-react'],
				plugins: ['@babel/plugin-syntax-dynamic-import']
			}
		}
	}]
};
const externals = {
	'react': 'React',
	'react-dom': 'ReactDOM'
};

module.exports = [{
	mode,
	watch,
	entry: {
		index: path.join(__dirname, 'src', 'index')
	},
	output: {
		path: path.join(__dirname, 'public', 'js'),
		publicPath: '/js/',
		filename: '[name].js',
		chunkFilename: '[name].js'
	},
	plugins: [
		new MiniCssExtractPlugin({
			filename: '[name].css',
			chunkFilename: '[id].css'
		}),
		new OptimizeCssAssetsPlugin({
			cssProcessorPluginOptions: {
				preset: ['default', { discardComments: { removeAll: true } }],
			}
		}),
		new HtmlWebpackPlugin({
			title: '',
			filename: '../index.html',
			template: path.join(__dirname, 'src', 'index.html'),
			hash: true
		})
	],
	module: _module,
	externals,
	resolve: {
		alias: {
			'css': path.join(__dirname, 'public', 'css')
		}
	},
	devServer: {
		open: true,
		port: 18888,
		contentBase: './public',
		historyApiFallback: true
		/*proxy: {
			'/api': {
				target: 'http://localhost:18080',
				changeOrigin: true,
			}
		}*/
	}
}];