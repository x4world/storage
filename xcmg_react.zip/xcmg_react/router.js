const Router = require('koa-router');
const router = new Router();
const send = require('koa-send');

async function sendHtml(ctx) {
	return send(ctx, 'index.html', {
		root: './public'
	});
}

router.get('/main', async ctx => {
	await sendHtml(ctx);
});

router.get('/login', async ctx => {
	await sendHtml(ctx);
});

router.get('/reg', async ctx => {
	await sendHtml(ctx);
});

router.get('/checkUpdate', async ctx => {
	let readme = require('./public/soft/readme.json');
	let {version} = ctx.query;
	if (version !== readme.version) {
		ctx.body = {
			result: 1,
			url: 'http://www.xcmgzfl.com:18888/soft/X-PRO-V' + readme.version + '.zip',
			changeLog: readme.changeLog
		};
	} else {
		ctx.body = {
			result: 0,
			msg: '当前已是最新版本'
		};
	}
});

router.get('/files', async ctx => {
	const fs = require('fs');
	const crypto = require('crypto');
	let ecuPath = './public/soft/ecus';
	let ecus = fs.readdirSync(ecuPath);
	let items = [];
	ecus.forEach(function(ecu) {
		let files = fs.readdirSync(ecuPath + '/' + ecu);
		files.forEach(function(file) {
			let type = null;
			if (file.endsWith('.dbc')) {
				type = 'DBC文件';
			} else if (file == 'FBL.s19') {
				type = '用于合成生产程序';
			} else if (file == 'WAKE.s19') {
				type = '用于合成休眠功能';
			} else if (file == 'Config.json') {
				type = '基础配置文件';
			} else if (file == 'GUI.html') {
				type = '图形化操作界面';
			} else if (file == 'Burn.flow') {
				type = 'UDS刷写流程文件';
			} else if (file == 'Driver.s19') {
				type = 'UDS刷写Flash驱动';
			}
			let item = {
				ecu,
				file,
				type,
				url: 'http://www.xcmgzfl.com:18888/soft/ecus/' + ecu + '/' + file,
				md5: crypto.createHash('md5').update(fs.readFileSync(ecuPath + '/' + ecu + '/' + file)).digest('hex').toUpperCase()
			};
			console.log(item);
			items.push(item);
		});
	});
	ctx.body = items;
});

module.exports = router.routes();