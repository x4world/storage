import mockData from './mock';
import React, {lazy} from 'react';
import {
	SafetyOutlined,
	CarOutlined,
	ToolOutlined,
	TeamOutlined
} from '@ant-design/icons';
import IconFont from './IconFont';
export default {
	request(opt) {
		opt = opt || {};
		let method = opt.method && opt.method.toUpperCase() || 'GET',
			url = opt.url || '',
			success = opt.success || function () {},
			fail = opt.fail || function() {},
			header = opt.header || {},
			data = opt.data || null,
			xmlHttp = new XMLHttpRequest();
		if (url !== '/api/register' && url !== '/api/login/username') {
			const token = localStorage.getItem('m_token');
			if (token) {
				header.Authorization = 'Bearer ' + token;
			}
			if (url === '/api/debug/getAll') {
				opt.success(mockData);
				return;
			}
	
		} 
		url = 'https://sc.xcmgzfl.com/xugongsuiche' + url;
		if (data && method === 'GET') {
			let params = [];
			for (let key in data) {
				params.push(key + '=' + data[key]);
			}
			url += (url.indexOf('?') === -1 ? '?' : '&') + params.join('&'); 
		}
		xmlHttp.open(method, url);
		for (let key in header) {
			xmlHttp.setRequestHeader(key, header[key]);
		}
		if (data) {
			xmlHttp.setRequestHeader('Content-Type', 'application/json');
			xmlHttp.send(JSON.stringify(data));
		} else {
			xmlHttp.send(null);
		}

		xmlHttp.onreadystatechange = function () {
			let resp = xmlHttp.responseText;
			if (xmlHttp.readyState === 4) {
				if (xmlHttp.status === 200) { 
					const result = JSON.parse(resp);
					if (result.status === 'OK') {
						success(result.data);
					} else if (result.status === 'ERROR') {
						fail(result.error);
					}
					//success(resp && type === 'json' ? JSON.parse(resp) : resp);
				} else if (xmlHttp.status > 400) {
					if (opt.fail) {
						opt.fail(JSON.stringify(resp));
					}
				} 
			}
		};
	},
	get(opt) {
		opt.method = 'GET';
		this.request(opt);
	},
	post(opt) {
		opt.method = 'POST';
		this.request(opt);
	},
	put(opt) {
		opt.method = 'PUT';
		this.request(opt);
	},
	delete(opt) {
		opt.method = 'DELETE';
		this.request(opt);
	},
	formatTimeUnit(unit) {
		if (unit < 10) {
			unit = '0' + unit;
		}
		return unit;
	},
	formatDate(date) {
		if (date) {
			const d = new Date(date);
			let year = d.getFullYear();
			let month = this.formatTimeUnit(d.getMonth() + 1);
			let day = this.formatTimeUnit(d.getDate());
			let hours = this.formatTimeUnit(d.getHours());
			let minutes = this.formatTimeUnit(d.getMinutes());
			return year + '-' + month + '-' + day + ' ' + hours + ':' + minutes;
		}
		return '';
	},
	nodes: [{
		icon: <CarOutlined />,
		title: '车辆监控',
		children: [{
			title: '实时监控',
			page: lazy(() => import('../pages/VehicleMonitorPage'))
		}, {
			title: '工况参数',
			page: lazy(() => import('../pages//VehicleDataPage'))
		}, {
			title: '远程控制'
		}]
	}, {
		icon: <ToolOutlined />,
		title: '技术管理',
		children: [{
			title: '模板管理',
			page: lazy(() => import('../pages/TemplatePage'))
		}, {
			title: '故障库管理',
			page: lazy(() => import('../pages/FaultPage'))
		}, {
			title: '协议管理',
			page: lazy(() => import('../pages/ProtocolPage'))
		}]
	}, {
		icon: <IconFont type="icon-cog" />,
		title: '系统管理',
		children: [{
			title: '操作日志',
			page: lazy(() => import('../pages/OperateLogPage'))
		}, {
			title: '消息管理',
			page: lazy(() => import('../pages/MessagePage'))
		}, {
			title: '客户管理',
			page: lazy(() => import('../pages/UserApplyPage'))
		}]
	}, {
		icon: <SafetyOutlined />,
		title: '权限管理',
		children: [{
			title: '组织管理',
			page: lazy(() => import('../pages/DeparementPage'))
		}, {
			title: '角色管理',
			page: lazy(() => import('../pages/RolePage'))
		}, {
			title: '用户管理',
			page: lazy(() => import('../pages/UserPage'))
		}]
	}, {
		icon: <TeamOutlined />,
		title: '客服管理',
		children: [{
			title: '人员管理',
			page: lazy(() => import('../pages/PeopleManagePage'))
		}, {
			title: '人员打卡',
			page: lazy(() => import('../pages/AttendancePage'))
		}, {
			title: '服务车管理',
			page: lazy(() => import('../pages/ServiceCarPage'))
		}, {
			title: '外出提报',
			page: lazy(() => import('../pages/OutsidePage'))
		}, {
			title: '节假日提报',
			page: lazy(() => import('../pages/HolidayPage'))
		}, {
			title: '工时管理',
			page: lazy(() => import('../pages/WorkTimePage'))
		}]
	}],
	notifyPage: lazy(() => import('../pages/NotifyPage'))
};