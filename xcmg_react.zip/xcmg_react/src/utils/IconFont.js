import { createFromIconfontCN } from '@ant-design/icons';

const IconFont = createFromIconfontCN({
	scriptUrl: '//at.alicdn.com/t/font_2017488_lkdgv86blg.js',
});

export default IconFont;