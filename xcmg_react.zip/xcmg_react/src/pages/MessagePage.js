import React, {useState} from 'react';
import {Radio} from 'antd';
import BussinessPage from './BussinessPage';
import AnnouncementPage from './AnnouncementPage';
import styles from './RolePage.less';
export default function MessagePage() {
	const [messageType, setMessageType] = useState('bussiness');
    
	function onChange(e) {
		setMessageType(e.target.value);
	}
    
	return (
		<div className={styles.container}>
			<div style={{ marginBottom: 10 }}>
				<Radio.Group value={messageType} buttonStyle='solid' onChange={onChange}>
					<Radio.Button value='bussiness'>业务消息</Radio.Button>
					<Radio.Button value='announcement'>公告消息</Radio.Button>
				</Radio.Group>
			</div>
			{
				messageType === 'bussiness'
                &&
                <BussinessPage />
			}
			{
				messageType === 'announcement'
                &&
                <AnnouncementPage />
			}
		</div>
	);
}