/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, Button, Modal, Form, Tooltip, Popconfirm, DatePicker, Upload} from 'antd';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';
import {
	PlusOutlined
} from '@ant-design/icons';

export default function WorkTimePage() {
	const [form] = Form.useForm();
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [param, setParam] = useState('');
	const [dateRange, setDateRange] = useState(null);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '工时产品型号',
		dataIndex: 'type'
	}, {
		title: '工时类别',
		dataIndex: 'category'
	}, {
		title: '工时费用项目',
		dataIndex: 'cost'
	}, {
		title: '工时（h）',
		dataIndex: 'hour'
	}, {
		title: '创建时间',
		dataIndex: 'createTime',
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];

	useEffect(() => {
		load();
	}, []);

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/people/workitem/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				param,
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/people/workitem/${key}`,
			success: () => onClose(true)
		});
	}

	function onEdit(record) {
		setEdit(record.key);
		form.setFieldsValue(record);
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				$.post({
					url: '/admin/people/workitem',
					data,
					fail: onSaveFail,
					success: () => onClose(true),
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit;
				$.put({
					url: '/admin/people/workitem',
					data,
					fail: onSaveFail,
					success: () => onClose(true)
				});
			});
		}
	}
    
	function onSaveFail(error) {
		Modal.error({
			title: '错误',
			content: error.description
		});
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 

	function toAdd() {
		setEdit(true);
		form.resetFields();
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function importExcel() {

	}

	function onChange(info) {
		if (info.file.status !== 'uploading') {
			console.log(info.file, info.fileList);
		}
		if (info.file.status === 'done') {
			//message.success(`${info.file.name} file uploaded successfully`);
		} else if (info.file.status === 'error') {
			//message.error(`${info.file.name} file upload failed.`);
		}
	}

	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space size="large">
					<Input placeholder='产品型号/类别/费用' onChange={e => setParam(e.target.value)} style={{ width: 300 }} value={param} />
					<DatePicker.RangePicker onChange={onDateChange} value={dateRange} />
					<Button type="primary" onClick={() => load()}>查询</Button>
					<Button type='primary' icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
					<Button type="primary" href="https://sc.xcmgzfl.com/xugongsuiche/admin/people/workitem/export">导出</Button>
					<Upload headers={{Authorization: 'Bearer ' + localStorage.getItem('m_token')}} name="file" action="https://sc.xcmgzfl.com/xugongsuiche/admin/people/workitem/import" showUploadList={false} onChange={onChange}><Button type="primary" onClick={() => importExcel()}>导入</Button></Upload>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>  
			<Modal
				title="编辑工时条目"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={450}
			>
				<Form labelCol={{ span: 7 }} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="工时产品型号"
						name="type"
						rules={[{ required: true, message: '工时产品型号' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="工时类别"
						name="category"
						rules={[{ required: true, message: '工时类别' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="工时费用项目"
						name="cost"
						rules={[{ required: true, message: '工时费用项目' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="工时"
						name="hour"
						rules={[{ required: true, message: '工时' }]}
					>
						<Input />
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}