/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, Radio, Popconfirm, Tooltip, Modal, Form, Select} from 'antd';
import IconFont from '../utils/IconFont';
import styles from './RolePage.less';
import $ from '../utils/CommonUtil';

import {
	CheckOutlined,
	CloseOutlined
} from '@ant-design/icons';

export default function UserApplyPage() {
	const [showArgee, setShowArgee] = useState(false);
	const [showRefuse, setShowRefuse] = useState(false);
	const [agreeForm] = Form.useForm();
	const [refuseForm] = Form.useForm();
	const [loading, setLoading] = useState(false);
	const [param, setParam] = useState('');
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	});
	const [type, setType] = useState('submit');
	const columns = [{
		title: '序号',
		render:(text,record,index)=>`${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '用户名',
		dataIndex: 'username'
	}, {
		title: '真实姓名',
		dataIndex: 'realname'
	}, {
		title: '手机号码',
		dataIndex: 'phoneNumber'
	}, {
		title: '申请理由',
		dataIndex: 'remarks'
	}, {
		title: '申请日期',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="同意"><a href="javascript:;" className={styles.icon} onClick={() => toAgree(record.key)}><CheckOutlined /></a></Tooltip>
				<Tooltip title="拒绝"><a href="javascript:;" className={styles.icon} onClick={() => toRefuse(record.key)}><CloseOutlined /></a></Tooltip>
				<Tooltip title="删除">
					<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Popconfirm>
				</Tooltip>
			</Space>
		)
	}];

	useEffect(() => {
		load();
	}, [type]);
    
	function toAgree(id) {
		setShowArgee(true);
		agreeForm.resetFields();
		agreeForm.id = id;
	}

	function onAgree() {
		$.put({
			url: '/api/approve/agree/' + agreeForm.getFieldValue('type'),
			data: {
				id: agreeForm.id
			},
			success: () => {
				setShowArgee(false);
				load();
			}
		});
	}
    
	function toRefuse(id) {
		setShowRefuse(true);
		refuseForm.resetFields();
		refuseForm.id = id;
	}
    
	function onRefuse() {
		$.put({
			url: '/api/approve/refuse',
			data: {
				id: refuseForm.id,
				feedback: refuseForm.getFieldValue('feedback')
			},
			success: () => {
				setShowRefuse(false);
				load();
			}
		});
	}

	function onDelete(key) {
		$.delete({
			url: `/api/approve/${key}`,
			success: () => load()
		});
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/api/approve/page/${type}/${pagination.current}/${pagination.pageSize}`,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			},
			fail: error => {
				Modal.error({
					title: '错误',
					content: error.description
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onChange(e) {
		setType(e.target.value);
	}

	return (
		<div className={styles.container} style={{overflowY: 'auto'}}>
			<div style={{ marginBottom: 10 }}>
				<Radio.Group value={type} buttonStyle='solid' onChange={onChange}>
					<Radio.Button value='submit'>未审批</Radio.Button>
					<Radio.Button value='agree'>已注册</Radio.Button>
					<Radio.Button value='refuse'>已拒绝</Radio.Button>
				</Radio.Group>
			</div>
			<div className={styles.header}>
				<Input.Search placeholder='请输入关键字查询' enterButton onChange={e => setParam(e.target.value)} onSearch={load} style={{ width: 300 }} value={param} />
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} pagination={data.pagination} columns={columns} dataSource={data.rows} rowSelection={{ type: 'checkbox' }} size='small' />
				</div>
			</div>  
			<Modal
				title="同意申请"
				centered
				visible={showArgee}
				onCancel={() => setShowArgee(false)}
				onOk={onAgree}
				width={450}>
				<Form form={agreeForm}>
					<Form.Item
						label="客户类型"
						name="type"
						initialValue="common">
						<Select optionFilterProp="children">
							<Select.Option value="common">个人车主</Select.Option>
							<Select.Option value="business">大客户</Select.Option>
						</Select>
					</Form.Item>
				</Form>
			</Modal> 
			<Modal
				title="拒绝申请"
				centered
				visible={showRefuse}
				onCancel={() => setShowRefuse(false)}
				onOk={onRefuse}
				width={450}>
				<Form form={refuseForm}>
					<Form.Item
						label="拒绝原因"
						name="feedback">
						<Input.TextArea rows={4} />
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}