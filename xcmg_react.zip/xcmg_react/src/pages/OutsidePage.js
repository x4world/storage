/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, DatePicker, Button, Modal, Image, Popconfirm, Tooltip, Select} from 'antd';
import moment from 'moment';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';
import tbStyles from './OutsidePage.less';

function Detail(props) {
	const [edit, setEdit] = useState(false);
	const [record, setRecord] = useState({...props.record});
	const [items, setItems] = useState(record && record.workItems ? [...record.workItems] : null);

	function save() {
		$.put({
			url: '/api/people/outside',
			data: record,
			success: function() {
				setEdit(false);
				props.onRecordChange(record);
			}
		});
	}

	function updateWorkCategory(index, workCategory) {
		let item = items[index];
		item.workCategory = workCategory;
		for (let i = 0; i < props.items.length; i++) {
			let _item = props.items[i];
			if (item.workCategory == _item.category && item.workCost == _item.cost) {
				item.workHour = _item.hour;
				break;
			}
		}
		setItems(items);
	}

	function updateWorkCost(index, workCost) {
		let item = items[index];
		item.workCost = workCost;
		for (let i = 0; i < props.items.length; i++) {
			let _item = props.items[i];
			if (item.workCategory == _item.category && item.workCost == _item.cost) {
				item.workHour = _item.hour;
				break;
			}
		}
		setItems(items);
	}

	function updateStartTime(index, startTime) {
		let item = items[index];
		item.workStartTime = startTime;
		setItems(items);
	}

	function updateEndTime(index, endTime) {
		let item = items[index];
		item.workEndTime = endTime;
		setItems(items);
	}

	function getWorkTypes() {
		let items = [];
		let map = {};
		props.items.forEach(function(item) {
			if (!map[item.type]) {
				items.push(item);
				map[item.type] = 1;
			}
		});
		return items;
	}

	function getWorkCategorys() {
		let items = [];
		let map = {};
		props.items.forEach(function(item) {
			if (item.type == record.workType && !map[item.category]) {
				items.push(item);
				map[item.category] = 1;
			}
		});
		return items;
	}

	function getWorkCosts(index) {
		let ret = [];
		props.items.forEach(function(item) {
			if (item.type == record.workType && item.category == items[index].workCategory) {
				ret.push(item);
			}
		});
		return ret;
	}

	let diff1 = (record.startTime && record.endTime) ? ((new Date(record.endTime).getTime() - new Date(record.startTime).getTime()) / 1000 / 3600).toFixed(1) + 'h' : '';
	let diff2 = (record.backStartTime && record.backEndTime) ? ((new Date(record.backEndTime).getTime() - new Date(record.backStartTime).getTime()) / 1000 / 3600).toFixed(1) + 'h' : '';
	return (
		<div>
			<div className={tbStyles.title}>工时信息</div>
			<div>
				<table className={tbStyles.tb}>
					<tr>
						<td>姓名</td>
						<td>{record.realname}</td>
						<td>手机号码</td>
						<td>{record.phoneNumber}</td>
						<td>提报时间</td>
						<td>{edit ? <DatePicker style={{padding: 0}} showTime defaultValue={moment(record.createTime, 'YYYY-MM-DD HH:mm:ss')} onChange={e => setRecord({...record, createTime: e.target.value})}/> : record.createTime}</td>
					</tr>
					<tr>
						<td>服务信息单号</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.workCode} onChange={e => setRecord({...record, workCode: e.target.value})}/> : record.workCode}</td>
						<td>工时产品型号</td>
						<td>
							{
								edit
									?
									<Select style={{ width: 160 }} showSearch defaultValue={record.workType} onChange={value => setRecord({...record, workType: value})}>
										{
											getWorkTypes().map((_item, index) => (
												<Select.Option key={index} value={_item.type}>{_item.type}</Select.Option>
											))
										}
									</Select>
									:
									record.workType
							}
						</td>
						<td>备注</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.workRemarks} onChange={e => setRecord({...record, workRemarks: e.target.value})}/> : record.workRemarks}</td>
					</tr>
				</table>
			</div>
			{
				items
				&&
				items.map((item, index) => {
					let hour = ((new Date(item.workEndTime).getTime() - new Date(item.workStartTime).getTime()) / 1000 / 3600).toFixed(1);
					return [
						<div key="d1" className={tbStyles.title} style={{marginTop: 12}}>工时{record.workItems.length > 1 && '(' + (index + 1) + ')'}</div>,
						<div key="d2">
							<table className={tbStyles.tb}>
								<tr>
									<td>工时类别</td>
									<td>
										{
											edit
												?
												<Select style={{width: 160}} showSearch defaultValue={item.workCategory} onChange={value => updateWorkCategory(index, value)}>
													{
														getWorkCategorys().map((_item, index) => (
															<Select.Option key={index} value={_item.category}>{_item.category}</Select.Option>	
														))
													}
												</Select>
												:
												item.workCategory
										}
									</td>
									<td>工时费用项目</td>
									<td>
										{
											edit
												?
												<Select style={{width: 160}} showSearch defaultValue={item.workCost} onChange={value => updateWorkCost(index, value)}>
													{
														getWorkCosts(index).map((_item, index) => (
															<Select.Option key={index} value={_item.cost}>{_item.cost}</Select.Option>	
														))
													}
												</Select>
												:
												item.workCost
										}
									</td>
									<td>工时（h）</td>
									<td>{item.workHour}</td>
								</tr>
								<tr>
									<td>开始时间</td>
									<td>{edit ? <DatePicker onChange={(date, dateString) => updateStartTime(index, dateString)} showTime style={{padding: 0}} defaultValue={item.workStartTime ? moment(item.workStartTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : item.workStartTime}</td>
									<td>结束时间</td>
									<td>{edit ? <DatePicker onChange={(date, dateString) => updateEndTime(index, dateString)} showTime style={{padding: 0}} defaultValue={item.workEndTime ? moment(item.workEndTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : item.workEndTime}</td>
									<td>工作时间</td>
									<td>{hour}</td>
								</tr>
							</table>
						</div>
					];
				})
			}
			<div className={tbStyles.title} style={{marginTop: 12}}>单程信息</div>
			<div>
				<table className={tbStyles.tb}>
					<tr>
						<td>车牌号</td>
						<td>{record.plateNum}</td>
						<td>出发地</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.startLocation} onChange={e => setRecord({...record, startLocation: e.target.value})}/> : record.startLocation}</td>
						<td>到达地</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.endLocation} onChange={e => setRecord({...record, endLocation: e.target.value})}/> : record.endLocation}</td>
					</tr>
					<tr>
						<td>出发时间</td>
						<td>{edit ? <DatePicker onChange={(date, dateString) => setRecord({...record, startTime: dateString})} showTime style={{padding: 0}} defaultValue={record.startTime ? moment(record.startTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : record.startTime}</td>
						<td>到达时间</td>
						<td>{edit ? <DatePicker onChange={(date, dateString) => setRecord({...record, endTime: dateString})} showTime style={{padding: 0}} defaultValue={record.endTime ? moment(record.endTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : record.endTime}</td>
						<td>行驶时间</td>
						<td>{diff1}</td>
					</tr>
					<tr>
						<td>行驶里程(km)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.mileage} onChange={e => setRecord({...record, mileage: e.target.value})}/> : record.mileage}</td>
						<td>服务类型</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.serviceType} onChange={value => setRecord({...record, serviceType: value})}>
										<Select.Option value="走访">走访</Select.Option>
										<Select.Option value="安装">安装</Select.Option>
										<Select.Option value="培训">培训</Select.Option>
										<Select.Option value="三包">三包</Select.Option>
										<Select.Option value="其他">其他</Select.Option>
									</Select>
									:
									record.serviceType
							}
						</td>
						<td>ETC费用(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.etcCost} onChange={e => setRecord({...record, etcCost: e.target.value})}/> : record.etcCost}</td>
					</tr>
					<tr>
						<td>是否加油</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.fuelStatus} onChange={value => setRecord({...record, fuelStatus: value})}>
										<Select.Option></Select.Option>
										<Select.Option value={1}>是</Select.Option>
										<Select.Option value={0}>否</Select.Option>
									</Select>
									:
									record.fuelStatus ? '是' : '否'
							}
						</td>
						<td>加油费用(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.fuelCost} onChange={e => setRecord({...record, fuelCost: e.target.value})}/> : record.fuelCost}</td>
						<td>里程数(km)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.totalMileage} onChange={e => setRecord({...record, totalMileage: e.target.value})}/> : record.totalMileage}</td>
					</tr>
					<tr>
						<td>图片</td>
						<td>{record.photo ? <a href="javascript:;" style={{color: '#1E90FD'}} onClick={() => props.onShowPhoto(record.photo)}>查看</a> : ''}</td>
						<td>是否保养</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.maintainStatus} onChange={value => setRecord({...record, maintainStatus: value})}>
										<Select.Option></Select.Option>
										<Select.Option value={1}>是</Select.Option>
										<Select.Option value={0}>否</Select.Option>
									</Select>
									:
									record.maintainStatus ? '是' : '否'
							}
						</td>
						<td>车辆保养费(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.maintainCost} onChange={e => setRecord({...record, maintainCost: e.target.value})}/> : record.maintainCost}</td>
					</tr>
					<tr>
						<td>保养内容</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.maintainContent} onChange={e => setRecord({...record, maintainContent: e.target.value})}/> : record.maintainContent}</td>
						<td>备注</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.remarks} onChange={e => setRecord({...record, remarks: e.target.value})}/> : record.remarks}</td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</div>
			<div className={tbStyles.title} style={{marginTop: 12}}>返程信息</div>
			<div>
				<table className={tbStyles.tb}>
					<tr>
						<td>车牌号</td>
						<td>{record.backPlateNum}</td>
						<td>出发地</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backStartLocation} onChange={e => setRecord({...record, backStartLocation: e.target.value})}/> : record.backStartLocation}</td>
						<td>到达地</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backEndLocation} onChange={e => setRecord({...record, backEndLocation: e.target.value})}/> : record.backEndLocation}</td>
					</tr>
					<tr>
						<td>出发时间</td>
						<td>{edit ? <DatePicker onChange={(date, dateString) => setRecord({...record, backStartTime: dateString})} showTime style={{padding: 0}} defaultValue={record.backStartTime ? moment(record.backStartTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : record.backStartTime}</td>
						<td>到达时间</td>
						<td>{edit ? <DatePicker onChange={(date, dateString) => setRecord({...record, backEndTime: dateString})} showTime style={{padding: 0}} defaultValue={record.backEndTime ? moment(record.backEndTime, 'YYYY-MM-DD HH:mm:ss') : null}/> : record.backEndTime}</td>
						<td>行驶时间</td>
						<td>{diff2}</td>
					</tr>
					<tr>
						<td>行驶里程(km)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backMileage} onChange={e => setRecord({...record, backMileage: e.target.value})}/> : record.backMileage}</td>
						<td>服务类型</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.backServiceType} onChange={value => setRecord({...record, backServiceType: value})}>
										<Select.Option value="走访">走访</Select.Option>
										<Select.Option value="安装">安装</Select.Option>
										<Select.Option value="培训">培训</Select.Option>
										<Select.Option value="三包">三包</Select.Option>
										<Select.Option value="其他">其他</Select.Option>
									</Select>
									:
									record.backServiceType
							}
						</td>
						<td>ETC费用(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backEtcCost} onChange={e => setRecord({...record, backEtcCost: e.target.value})}/> : record.backEtcCost}</td>
					</tr>
					<tr>
						<td>是否加油</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.backFuelStatus} onChange={value => setRecord({...record, backFuelStatus: value})}>
										<Select.Option></Select.Option>
										<Select.Option value={1}>是</Select.Option>
										<Select.Option value={0}>否</Select.Option>
									</Select>
									:
									record.backFuelStatus ? '是' : '否'
							}
						</td>
						<td>加油费用(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backFuelCost} onChange={e => setRecord({...record, backFuelCost: e.target.value})}/> : record.backFuelCost}</td>
						<td>里程数(km)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backTotalMileage} onChange={e => setRecord({...record, backTotalMileage: e.target.value})}/> : record.backTotalMileage}</td>
					</tr>
					<tr>
						<td>图片</td>
						<td>{record.backPhoto ? <a href="javascript:;" style={{color: '#1E90FD'}} onClick={() => props.onShowPhoto(record.backPhoto)}>查看</a> : ''}</td>
						<td>是否保养</td>
						<td>
							{
								edit 
									? 
									<Select defaultValue={record.backMaintainStatus} onChange={value => setRecord({...record, backMaintainStatus: value})}>
										<Select.Option></Select.Option>
										<Select.Option value={1}>是</Select.Option>
										<Select.Option value={0}>否</Select.Option>
									</Select>
									:
									record.backMaintainStatus ? '是' : '否'
							}
						</td>
						<td>车辆保养费(元)</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backMaintainCost} onChange={e => setRecord({...record, backMaintainCost: e.target.value})}/> : record.backMaintainCost}</td>
					</tr>
					<tr>
						<td>保养内容</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backMaintainContent} onChange={e => setRecord({...record, backMaintainContent: e.target.value})}/> : record.backMaintainContent}</td>
						<td>备注</td>
						<td>{edit ? <Input style={{padding: 0}} defaultValue={record.backRemarks} onChange={e => setRecord({...record, backRemarks: e.target.value})}/> : record.backRemarks}</td>
						<td></td>
						<td></td>
					</tr>
				</table>
			</div>
			<div style={{marginTop: 12, display: 'flex', justifyContent: 'space-between'}}>
				<div style={{display: 'flex', flex: 1}}>
					<strong>提报地点：</strong>
					{edit ? <Input style={{padding: 0, width: 300, height: 24}} defaultValue={record.location} onChange={e => setRecord({...record, location: e.target.value})}/> : <strong>{record.location}</strong>}
				</div>
				<div>
					{
						edit
							?
							<Button type="primary" onClick={() => save()}>保存</Button>
							:
							<Button type="primary" onClick={() => setEdit(true)}>编辑</Button>
					}
				</div>
			</div>
		</div>
	);
}
export default function OutsidePage() {
	const [loading, setLoading] = useState(false);
	const [dateRange, setDateRange] = useState(null);
	const [param, setParam] = useState('');
	const [record, setRecord] = useState(null);
	const [photo, setPhoto] = useState(null);
	const [items, setItems] = useState([]);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		width: 50,
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '姓名',
		dataIndex: 'realname', 
		width: 100,
		render: (text, record) => <a href="javascript:;" style={{color: '#1E90FD'}} onClick={() => setRecord(record)}>{text}</a>
	}, {
		title: '手机号码',
		dataIndex: 'phoneNumber'
	}, {
		title: '提报日期',
		dataIndex: 'createTime'
	}, {
		title: '服务信息单号',
		dataIndex: 'workCode',
		width: 140
	}, {
		title: '工时产品型号',
		dataIndex: 'workType',
		width: 140,
	}, {
		title: '工时类别',
		render: (text, record) => (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0].workCategory : ''
	}, {
		title: '工时费用项目',
		render: (text, record) => (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0].workCost : ''
	}, {
		title: '工时（h）',
		width: 100,
		render: (text, record) => (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0].workHour : ''
	}, {
		title: '开始时间',
		render: (text, record) => (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0].workStartTime : ''
	}, {
		title: '结束时间',
		render: (text, record) => (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0].workEndTime : ''
	}, {
		title: '工作时间',
		width: 110,
		render:  (text,record) => 
		{
			let item = (record.workItems != null && record.workItems.length) > 0 ? record.workItems[0] : null;
			if (item)
			{
				return ((new Date(item.workEndTime).getTime() - new Date(item.workStartTime).getTime()) / 1000 / 3600).toFixed(1);
			}
			return '';
		}
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => setRecord(record)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];

	useEffect(() => {
		load();

		$.get({
			url: '/admin/people/workitem/all',
			success: items => {
				setItems(items);
			}
		});
	}, []);

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/people/outside/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				username: param,
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}

	function onParamChange(e) {
		setParam(e.target.value);
	}

	function handleCancel() {
		setRecord(null);
	}

	function closePhoto() {
		setPhoto(null);
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/people/outside/${key}`,
			success: () => load()
		});
	}

	function updateRecord(record) {
		data.rows.forEach(function(row) {
			if (row.id === record.id) {
				Object.assign(row, record);
			}
		});
		setData(data);
	}
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space size="large">
					<div>关键字：<Input onChange={onParamChange} style={{width: 300}}/></div>
					<div>日期：<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/></div>
					<Button type="primary" onClick={() => load()}>查询</Button>
					<Button type="primary" href={`https://sc.xcmgzfl.com/xugongsuiche/admin/people/outside/export?username=${param}&start=${dateRange ? dateRange[0].format('yyyy-MM-DD') : ''}&end=${dateRange ? dateRange[1].format('yyyy-MM-DD') : ''}`}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} size="small"/>
				</div>
			</div>  
			<Modal title="详情" width={1024} visible={record !== null} onCancel={handleCancel} footer={null} destroyOnClose>
				{record && <Detail record={record} onRecordChange={newRecord => updateRecord(newRecord)} items={items} onShowPhoto={url => setPhoto(url)}/>}
			</Modal> 
			<Modal title="图片" visible={photo != null} onOk={closePhoto} onCancel={closePhoto} destroyOnClose>
				{
					photo 
						&&
						<Image.PreviewGroup>
							{
								photo.map(url => <Image key={url} width={200} src={'https://heyi-photo.oss-cn-shanghai.aliyuncs.com' + url}/>)
							}
						</Image.PreviewGroup>
				}
			</Modal>
		</div>
	);
}