/* eslint-disable react/display-name */
import React, {useState, useEffect, useRef} from 'react';
import { Table, Space, Input, Button, Modal, Tooltip, DatePicker} from 'antd';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';

export default function ServiceCarPage() {
	const [showMap, setShowMap] = useState(false);
	const [loading, setLoading] = useState(false);
	const [dateRange, setDateRange] = useState(null);
	const [plateNum, setPlateNum] = useState(null);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 
	const recordRef = useRef(null);
	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '车牌号',
		dataIndex: 'plateNum'
	}, {
		title: '终端编号',
		dataIndex: 'terminalId'
	}, {
		title: '驾驶员',
		dataIndex: 'username'
	}, {
		title: '状态',
		dataIndex: 'onlineStatus',
		render: text => (text == 1 ? '在线' : '离线')
	}, {
		title: '更新时间',
		dataIndex: 'gpsTime',
	}, {
		title: '经度',
		dataIndex: 'longitude',
	}, {
		title: '纬度',
		dataIndex: 'latitude',
	}, {
		title: '位置',
		dataIndex: 'location',
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="地图"><a href="javascript:;" className="normal" onClick={() => openMap(record)}>地图</a></Tooltip>
			</Space>
		)
	}];

	useEffect(() => {
		load();
	}, []);

	function load(pagination, param = '') {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/people/vehicle/page/${pagination.current}/${pagination.pageSize}`,
			data: param ? {param} : null,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onCloseMap() {
		setShowMap(false);
	} 

	function openMap(record) {
		setShowMap(true);
		recordRef.current = record;
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}

	function onRef(ref) {
		if (ref != null) {
			const BMapGL = window.BMapGL;
			const map = new BMapGL.Map(ref);
			map.enableDragging();
			map.enableScrollWheelZoom(true);
			const point = new BMapGL.Point(recordRef.current.longitude, recordRef.current.latitude);
			const marker = new BMapGL.Marker(point, {
				icon: new BMapGL.Icon('/images/fwc_work_m.png', new BMapGL.Size(26, 30))
			});
			map.addOverlay(marker);
			map.centerAndZoom(point, 15);
		}
	}

	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="车牌号" enterButton onChange={e => setPlateNum(e.target.value)} onSearch={value => load(null, value)} style={{width: 300}}/>
					<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/>
					<Button type="primary" href={`https://sc.xcmgzfl.com/xugongsuiche/admin/people/gps/export?plateNum=${plateNum}&start=${dateRange ? dateRange[0].format('yyyy-MM-DD') : ''}&end=${dateRange ? dateRange[1].format('yyyy-MM-DD') : ''}`}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>  
			<Modal
				title="地图"
				centered
				visible={showMap}
				onCancel={onCloseMap}
				footer={null}
				width={600}
				bodyStyle={{padding: 0}}
				destroyOnClose
			>
				<div ref={container => onRef(container)} style={{width: 600, height: 400}}></div>
			</Modal> 
		</div>
	);
}