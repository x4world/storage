/* eslint-disable react/display-name */
import React, {useEffect, useState} from 'react';
import {Radio, Space, Tooltip, Popconfirm, Input, Table} from 'antd';
import styles from './RolePage.less';
import $ from '../utils/CommonUtil';
import IconFont from '../utils/IconFont';

export default function MessagePage() {
	const [messageType, setMessageType] = useState('bussiness');
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 20
		}
	});
    
	function onChange(e) {
		setMessageType(e.target.value);
	}
    
	useEffect(() => {
		if (messageType === 'bussiness') {
			$.get({
				url: '/api/message/vehicle/work/new',
				success: data => {
					setData({
						rows: data,
						pagination: {
							total: data.length,
							current: 1,
							pageSize: 10
						}
					});
				}
			});
		} else if (messageType === 'announcement') {
			$.get({
				url: '/api/message/platform/new',
				success: data => {
					setData({
						rows: data,
						pagination: {
							total: data.length,
							current: 1,
							pageSize: 10
						}
					});
				}
			});
		}
	}, messageType);

	function onDelete() {

	}

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '内容',
		dataIndex: 'message'
	}, {
		title: '时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
				<Tooltip title="删除">
					<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
				</Tooltip>
			</Popconfirm>
		)
	}];
    
	return (
		<div className={styles.container}>
			<div style={{ marginBottom: 10 }}>
				<Radio.Group value={messageType} buttonStyle='solid' onChange={onChange}>
					<Radio.Button value='bussiness'>业务消息</Radio.Button>
					<Radio.Button value='announcement'>公告消息</Radio.Button>
				</Radio.Group>
			</div>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder='请输入搜索内容' enterButton/>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table columns={columns} dataSource={data.rows} rowSelection={{ type: 'checkbox' }} size='small' />
				</div>
			</div>
		</div>
	);
}