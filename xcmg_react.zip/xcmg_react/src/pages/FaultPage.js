/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, Button, Modal, Form, Tooltip, Popconfirm} from 'antd';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';
import {
	ImportOutlined,
	ExportOutlined,
	PlusOutlined
} from '@ant-design/icons';

export default function FaultPage() {
	const [form] = Form.useForm();
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: 'ID',
		dataIndex: 'pdo'
	}, {
		title: '故障码',
		dataIndex: 'code'
	}, {
		title: '故障名称',
		dataIndex: 'remarks'
	}, {
		title: '辅助诊断方法',
		dataIndex: 'diagnostic'
	}, {
		title: '处理方法',
		dataIndex: 'process'
	}, {
		title: '创建时间',
		dataIndex: 'createTime',
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<a href="javascript:;" onClick={() => test(record)} className={styles.icon}><IconFont type="icon-tec"/></a>
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record.key)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];

	useEffect(() => {
		load();
	}, []);

	function test(fault) {
		$.post({
			url: '/admin/vehicle/work/message/send',
			data: {
				pdos: [fault.pdo],
				vehicleId: 29
			},
			success: () => {
				Modal.success({
					content: '故障已触发'
				});
			}
		});
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/vehicle/fault/page/${pagination.current}/${pagination.pageSize}`,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/vehicle/fault/${key}`,
			success: () => onClose(true)
		});
	}

	function onEdit(key) {
		setEdit(key);
		$.get({
			url: `/admin/vehicle/fault/${key}`,
			success: data => {
				form.setFieldsValue(data);
			}
		});
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				$.post({
					url: '/admin/vehicle/fault',
					data,
					success: () => onClose(true)
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit;
				$.put({
					url: '/admin/vehicle/fault',
					data,
					success: () => onClose(true)
				});
			});
		}
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 

	function toAdd() {
		setEdit(true);
		form.resetFields();
	}
    
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="故障码" enterButton onSearch={value => console.log(value)} style={{width: 300}}/>
					<Button type="primary" icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
					<Button icon={<ImportOutlined />}>导入</Button>
					<Button icon={<ExportOutlined />}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>  
			<Modal
				title="新增"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={450}
			>
				<Form labelCol={{ span: 5 }} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="ID"
						name="pdo"
						rules={[{ required: true, message: '故障码' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="故障码"
						name="code"
						rules={[{ required: true, message: '故障码' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="故障名称"
						name="remarks"
						rules={[{ required: true, message: '请输入故障名称' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="辅助诊断方法"
						name="diagnostic"
					>
						<Input.TextArea />
					</Form.Item>
					<Form.Item
						label="处理方法"
						name="process"
					>
						<Input.TextArea />
					</Form.Item>
					<Form.Item
						label="故障说明"
						name="phoneNumber"
					>
						<Input.TextArea />
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}