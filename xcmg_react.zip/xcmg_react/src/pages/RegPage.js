/* eslint-disable react/prop-types */
import React, { useEffect, useState, useRef } from 'react';
import { Steps, Input, Button, Form, Result, Modal } from 'antd';
import { Link } from 'react-router-dom';
import IconFont from '../utils/IconFont';
import styles from './RegPage.less';
import $ from '../utils/CommonUtil';

export default function RegPage(props) {
	const [step, setStep] = useState(0);
	const [phoneNumber, setPhoneNumber] = useState('');
	const [code, setCode] = useState('');
	const [count, setCount] = useState(0);

	function validatePhone() {
		$.post({
			url: '/api/register/mobile',
			data: {
				phoneNumber,
				code
			},
			success: () => {
				setStep(1);
			}
		});
	}

	function onFinish(data) {
		if (phoneNumber) {
			data.phoneNumber = phoneNumber;
			$.post({
				url: '/api/register',
				data,
				success: () => {
					setStep(2);
				}
			});
		}
	}

	function toLogin() {
		props.history.push('/login');
	}

	function getCode() {
		if (phoneNumber) {
			$.get({
				url: '/api/register/mobile/' + phoneNumber,
				success: () => {
					setCount(59);
				},
				fail: () => {
					Modal.error({
						title: '错误',
						content: '该手机号已注册'
					});
				}
			});
		}
	}

	function onPhoneInput(e) {
		setPhoneNumber(e.target.value);
	}

	function onCodeInput(e) {
		setCode(e.target.value);
	}

	useEffect(() => {
		if (count > 0) {
			const id = setInterval(() => setCount(count => count - 1), 1000);
			return () => {clearInterval(id);};
		}
	}, [count]);

	return (
		<div>
			<div className={styles.header}>
				<div className={styles.inner}>
					<img src="/images/logo2.png" className={styles.logo} />
					<div>已有帐号，请<Link to="/login" style={{ color: '#007EED' }}>登录</Link></div>
				</div>
			</div>
			<div className={styles.body}>
				<div className={styles.content}>
					<Steps current={step} labelPlacement="vertical" size="small">
						<Steps.Step title="验证手机号" />
						<Steps.Step title="填写帐号信息" />
						<Steps.Step title="提交成功" />
					</Steps>
					<div className={styles.form}>
						{
							step === 0
                            &&
                            <div>
                            	<Input size="large" placeholder="手机号码" onChange={onPhoneInput} prefix={<IconFont type="icon-phone" className={styles.formIcon}/>} />
                            	<div style={{ margin: '16px 0', display: 'flex' }}>
                            		<Input size="large" placeholder="手机验证码" onChange={onCodeInput} prefix={<IconFont type="icon-code" className={styles.formIcon}/>} style={{ flex: 1, marginRight: 8 }} />
                            		<Button size="large" style={{width: 120}} onClick={getCode} disabled={count > 0}>{count > 0 ? `重新发送(${count})` : '获取验证码'}</Button>
                            	</div>
                            	<Button type="primary" size="large" block onClick={validatePhone}>下一步</Button>
                            </div>
						}
						{
							step === 1
                            &&
                            <Form labelCol={{ span: 6 }} wrapperCol={{ span: 24 }} onFinish={onFinish}>
                            	<Form.Item
                            		label="用 户 名"
                            		name="username"
                            		rules={[{ required: true, message: '用户名不能为空' }]}>
                            		<Input />
                            	</Form.Item>
                            	<Form.Item
                            		label="设置密码"
                            		name="password"
                            		rules={[{ required: true, message: '密码不能为空' }]}>
                            		<Input.Password />
                            	</Form.Item>
                            	<Form.Item
                            		label="确认密码"
                            		name="confirm"
                            		dependencies={['password']}
                            		rules={[{ 
                            			required: true, 
                            			message: '请确认密码' 
                            		}, ({ getFieldValue }) => ({
                            			validator(rule, value) {
                            				if (!value || getFieldValue('password') === value) {
                            					return Promise.resolve();
										  	}
										  	return Promise.reject('两次输入的密码不一致');
                            			},
									  }),]}>
                            		<Input.Password />
                            	</Form.Item>
                            	<Form.Item
                            		label="客户全称"
                            		name="namePrefix"
                            		rules={[{ required: true, message: '客户全称不能为空' }]}>
                            		<Input />
                            	</Form.Item>
                            	<Form.Item
                            		label="真实姓名"
                            		name="realname"
                            		rules={[{ required: true, message: '真实姓名不能为空' }]}>
                            		<Input />
                            	</Form.Item>
                            	<Form.Item
                            		label="申请理由"
                            		name="remarks">
                            		<Input.TextArea rows={4} />
                            	</Form.Item>
                            	<Form.Item wrapperCol={{ offset: 2 }}>
                            		<Button type="primary" size="large" block htmlType="submit">提交</Button>
                            	</Form.Item>
                            </Form>
						}
						{
							step === 2
                            &&
                            <Result
                            	status="success"
                            	title="信息已提交！"
                            	subTitle="您提交的资料将会于3个工作日内进行审核，到时将会有信息通知您，请耐心等候!"
                            	extra={
                            		<Button type="primary" onClick={toLogin}>
                                        前往登录
                            		</Button>
                            	}
                            />
						}
					</div>
				</div>
			</div>
		</div>
	);
}
