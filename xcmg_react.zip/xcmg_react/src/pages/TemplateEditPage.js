/* eslint-disable react/prop-types */
import React, {useState, useContext, useEffect} from 'react';
import { Row, Col, Table, Space, Input, Button, Form, Modal, Select} from 'antd';
import styles from './TemplateEditPage.less';
const EditableContext = React.createContext();
import $ from '../utils/CommonUtil';

const columns = [{
	title: '参数名称',
	dataIndex: 'name',
	width: '15%'
}, {
	title: '地址',
	dataIndex: 'address'
}, {
	title: '传输数据类型',
	dataIndex: 'dataType'
}, {
	title: '传输数据范围',
	dataIndex: 'dataRange'
}, {
	title: '传输数据分辨率',
	dataIndex: 'dataResolution',
}, {
	title: '传输数据单位',
	dataIndex: 'dataUnit',
}, {
	title: '实际物理量单位',
	dataIndex: 'physicalUnit',
}, {
	title: '比例系数',
	dataIndex: 'dataRatio',
}, {
	title: '初始值',
	dataIndex: 'csz',
	width: 100,
	editable: true
}];

const EditableRow = ({ ...props }) => {
	const [form] = Form.useForm();
	return (
		<Form form={form} component={false}>
			<EditableContext.Provider value={form}>
				<tr {...props} />
			</EditableContext.Provider>
		</Form>
	);
};

const EditableCell = ({
	editing,
	editable,
	children,
	dataIndex,
	record,
	handleSave,
	...restProps
}) => {
	const form = useContext(EditableContext);
	const save = async () => {
		try {
			const values = await form.validateFields();
			handleSave({ ...record, ...values });
		} catch (errInfo) {
			console.log('Save failed:', errInfo);
		}
	};

	useEffect(() => {
		if (record) {
			form.setFieldsValue({
				[dataIndex]: record[dataIndex],
			});
		}
	}, [record]);
	let childNode = editable ? (
		<Form.Item
			style={{margin: 0}}
			name={dataIndex}
			rules={[{ required: true, message: '数值不能为空' }]}>
			<Input onBlur={save} disabled={!editing}/>
		</Form.Item>
	) : children;
	
	return <td {...restProps}>{childNode}</td>;
};

export default function TemplateEditPage(props) {
	const [pages, setPages] = useState([]);
	const [selected, setSelected] = useState({});
	const [visible, setVisible] = useState(false);
	const [importTplId, setImportTplId] = useState(null);
	const [importTpls, setImportTpls] = useState([]);
	const tableId = props.tableId || props.tpl.tableId;
	function onFinish(formData) {
		const values = [];
		const pageRemarks = [];
		const set = new Set();
		for (let m in selected) {
			selected[m].forEach(function(key) {
				set.add(key);
			});
		}
		
		pages.forEach(function(page) {
			page.items.forEach(function(item) {
				if (set.has(item.key)) {
					if (item.csz !== undefined && item.csz !== '') {
						values.push({
							itemAddress: item.key,
							value: item.csz
						});
					} 
				}
			});

			if (page.remark) {
				pageRemarks.push({
					pageCode: page.code,
					remark: page.remark
				});
			}
		});

		formData.values = values && values.length > 0 ? values : null;
		formData.pageRemarks = pageRemarks && pageRemarks.length > 0 ? pageRemarks : null;
		formData.tableId = tableId;
		if (values.length === 0) {
			formData.sensor = 0;
		} else {
			formData.sensor = 1;
		}

		if (props.tpl) {
			formData.id = props.tpl.id;
			$.put({
				url: `/api/tpl/${props.tplType}`,
				data: formData,
				success: onSave,
				fail: onSaveFail
			});
		} else {
			$.post({
				url: `/api/tpl/${props.tplType}`,
				data: formData,
				success: onSave,
				fail: onSaveFail
			});
		}
	}

	useEffect(() => {
		const map = {};
		const pageMap = {};
		if (props.tpl) {
			const arr = props.tpl.valueList;
			arr.forEach(function(obj) {
				map[obj.itemAddress] = obj.value;
			});
			const arr2 = props.tpl.pageRemarkList;
			if (arr2) {
				arr2.forEach(function(obj) {
					pageMap[obj.pageCode] = obj.remark;
				});
			}
		}

		$.get({
			url: '/api/tpl/' + props.tplType + '/table/' + props.tableId,
			success: data => {
				setImportTpls(data);
			}
		});

		$.get({
			url: `/admin/vehicle/parameter/table/details/${tableId}`,
			success: data => {

				data.pages.forEach(function(page, index) {
					if (pageMap[page.code]) {
						page.remark = pageMap[page.code];
					}
					page.items = page.items.filter(item => {
						return (props.tplType === 'config' && (item.type === 'CONFIG' || item.type === 'CALIBRATION')) || (props.tplType === 'set' && item.type === 'SET');
					});
					page.items.forEach(function(item) {
						item.key = item.address;
						if (map[item.address] !== undefined) {
							item.csz = map[item.address];
							item.editing = true;
							let keys = selected[index];
							if (!keys) {
								keys = selected[index] = [];
							}
							keys.push(item.address);
						}
					});
				});
				
				setPages(data.pages);
			}
		});

		/*groups[props.tplType].forEach(function(obj, index) {
			const items = [];
			let block = {
				page: obj.page,
				title: obj.title,
				items
			};
			
			obj.items.forEach(function(address) {
				const item = {
					...dict[address], key: address
				};
				if (map[address] !== undefined) {
					item.csz = map[address];
					item.editing = true;
					let keys = selected[index];
					if (!keys) {
						keys = selected[index] = [];
					}
					keys.push(address);
				}
				items.push(item);
			});
			if (pageMap[obj.page]) {
				block.remark = pageMap[obj.page];
			}
			blocks.push(block);
		});*/
	}, []);

	function onSave() {
		props.onRet();
	}

	function onSaveFail(error) {
		Modal.error({
			title: '错误',
			content: error.description
		});
	}

	function onSelected(pageIndex, keys) {
		selected[pageIndex] = keys;
		setSelected(selected);

		const set = new Set(keys);
		pages[pageIndex].items.forEach(function(item) {
			item.editing = set.has(item.key);
		});
		setPages(pages);
	}

	function handleSave(row) {
		for (let page of pages) {
			for (let item of page.items) {
				if (item.key === row.key) {
					item.csz = row.csz;
					return;
				}
			}
		}
	}

	function onRemarkChange(page, value) {
		page.remark = value;
		setPages(pages);
	}

	function onImport() {
		setVisible(true);
	}

	function onOk() {
		const tpl = importTpls[importTplId];
		const map = {};
		tpl.valueList.forEach(function(item) {
			map[item.itemAddress] = item.value;
		});
		pages.forEach(function(page, index) {
			let keys = selected[index] = [];
			const newItems = [];
			page.items.forEach(function(item) {
				const newItem = {...item};
				newItem.editing = true;
				newItem.csz = map[item.address];
				newItems.push(newItem);
				keys.push(item.address);
			});
			page.items = newItems;
		});

		setPages(pages);
		setVisible(false);
	}

	const columns2 = columns.map((col) => {
		if (!col.editable) {
			return col;
		}
	
		return {
			...col,
			onCell: record => ({
				record,
				editable: col.editable,
				dataIndex: col.dataIndex,
				title: col.title,
				editing: record.editing,
				handleSave
			})
		};
	});

	const components={body: {row: EditableRow, cell: EditableCell}};
	const tpl = props.tpl || {};

	return (
		<div>
			<Form className={styles.block} onFinish={onFinish} initialValues={{...tpl}}>
				<Row>
					<Col>
						<Form.Item
							name='name'
							label='模板名称'
							rules={[{ required: true, message: '请输入模板名称' }]}>
							<Input style={{width: 150}}/>
						</Form.Item>
					</Col>
					<Col offset={1}>
						<Form.Item
							name='vehicleType'
							label='车型代号'
							rules={[{ required: true, message: '请输入车型代号' }]}>
							<Input style={{width: 150}}/>
						</Form.Item>
					</Col>
					<Col offset={1}>
						<Form.Item
							name='version'
							label='版本号'
							rules={[{ required: true, message: '请输入版本号' }]}>
							<Input style={{width: 100}} placeholder="1.0" />
						</Form.Item>
					</Col>
					<Col style={{marginLeft: 10}}>
						<Space>
							<Button type='primary' style={{width: 100}} htmlType='submit'>保存</Button>
							<Button style={{width: 100}} onClick={onImport}>导入</Button>
							<Button style={{width: 100}} onClick={() => props.onRet()}>返回</Button>
						</Space>
					</Col>
				</Row>
				<Row>
					<Col span={24}>
						<Form.Item style={{marginBottom: 0}} name='tplRemarks' rules={[{ required: true, message: '请输入模板说明' }]}>
							<Input.TextArea rows={4} placeholder='模板说明'/>
						</Form.Item>
					</Col>
				</Row>
			</Form>
			{
				pages.map((page, index) => {
					const showDesc = page.items.findIndex(item => /标定$/.test(item.name)) !== -1;
					return (
						page.items.length > 0
							?
							<div key={index} className={styles.block} style={{marginTop: 20}}>
								<Table title={() => <div className={styles.titlebar}>{page.name}</div>} bordered pagination={false} components={components} columns={columns2} dataSource={page.items} rowSelection={{type: 'checkbox', selectedRowKeys: selected[index], onChange: keys => onSelected(index, keys)}} size='small'/>
								{props.tplType === 'config' && showDesc && <Input.TextArea rows={4} placeholder='操作提示' style={{marginTop: 16}} value={page.remark} onChange={e => onRemarkChange(page, e.target.value)}/>}
							</div>
							:
							null
					);
				})
			}
			<Modal
				title="导入模板"
				centered
				visible={visible}
				onCancel={() => setVisible(false)}
				onOk={onOk}
				width={450}
			>
				<Form>
					<Form.Item label="模板">
						<Select onChange={value => setImportTplId(value)} value={importTplId} showSearch optionFilterProp="children">
							{
								importTpls.map((tpl, index) => <Select.Option key={tpl.id} value={index}>{tpl.name + ' ' + tpl.version}</Select.Option>)
							}
						</Select>
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}