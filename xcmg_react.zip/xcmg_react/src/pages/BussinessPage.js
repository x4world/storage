/* eslint-disable react/display-name */
import React, {useState, useEffect, useRef} from 'react';
import { Table, Space, Input, Button, Radio, Popconfirm, Tooltip, Modal, Form, TreeSelect, DatePicker, Checkbox, TimePicker} from 'antd';
import IconFont from '../utils/IconFont';
import {
	PlusOutlined,
} from '@ant-design/icons';
import $ from '../utils/CommonUtil';
import moment from 'moment';
import styles from './RolePage.less';

const noticeOption = [
	{label: '离线', value: 'OFFLINE'}, 
	{label: '上线', value: 'ONLINE'}, 
	{label: '工作', value: 'START_UP'}, 
	{label: '停机', value: 'SHUT_DOWN'}, 
	{label: '故障', value: 'VEHICLE_FAULT'}, 
	//{label: '低压', value: 'LOW_PRESSURE'}
];
const subscribeOption = [{label: '工作时间', value: 'WORK_TIME'}];
export default function BussinessPage() {
	const userMap = useRef(null);
	const [edit, setEdit] = useState(false);
	const [form] = Form.useForm();
	const [loading, setLoading] = useState(false);
	const [vehicleTreeData, setVehicleTreeData] = useState(null);
	const [userTreeData, setUserTreeData] = useState(null);
	const [query, setQuery] = useState('');
	const [isTimerVisible, setTimerVisible] = useState(false);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	});
	const columns = [{
		title: '序号',
		render:(text,record,index)=>`${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '规则名称',
		dataIndex: 'name'
	}, {
		title: '生效时间',
		render:(text, record) => `${record.startDate}-${record.endDate}`
	}, {
		title: '创建人',
		dataIndex: 'creatorName'
	}, {
		title: '创建时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record)}><IconFont type="icon-edit"/></a></Tooltip>
				<Tooltip title="删除">
					<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Popconfirm>
				</Tooltip>
			</Space>
		)
	}];
    
	useEffect(() => {
		$.get({
			url: '/api/vehicle',
			success: vehicles => {
				const vehicleTreeData = [];
				vehicles.forEach(function(vehicle) {
					vehicleTreeData.push({
						title: vehicle.productNum,
						value: vehicle.id
					});
				});
				let data = [];
				let gmap = {};
				let groups = [
					['PRODUCE', '生产组'], 
					['CHECK', '检测组'], 
					['LAUNCH', '发车组'], 
					['SALE', '销售组']
				];
				groups.forEach(function (arr) {
					const groupid = arr[0];
					const name = arr[1];
					const parent = arr[2];
					const node = {
						title: name,
						key: 'g' + groupid,
						children: []
					};
					if (!parent) {
						data.push(node);
					} else {
						gmap[parent].children.push(node);
					}
					gmap[groupid] = node;
				});
				vehicles.forEach(function (vehicle) {
					const group = gmap[vehicle.group];
					if (group) {
						group.children.push({
							title: vehicle.productNum,
							icon: vehicle.icon,
							key: vehicle.id
						});
					}
				});
				setVehicleTreeData(data.filter(node => node.children.length > 0));
			}
		});
        
		$.get({
			url: '/admin/user/all',
			success: users => {
				$.get({
					url: '/admin/role/all',
					success: roles => {
						const map = {};
						const userTreeData = [];
						userMap.current = {};
						roles.forEach(function(role) {
							map[role.id] = [];
							userTreeData.push({
								title: role.name,
								value: 'r' + role.id,
								children: map[role.id]
							});
						});
						users.forEach(function(user) {
							map[user.roleId].push({
								title: `${user.realname}(${user.username})`,
								value: user.id
							});
							userMap.current[user.id] = user;
						});
						setUserTreeData(userTreeData.filter(role => role.children.length > 0));
					}
				});
			}
		});

		load();
	}, []);
    
	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/vehicle/work/message/page/${pagination.current}/${pagination.pageSize}`,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onEdit(record) {
		setEdit(record);
		let data = {};
		data.name = record.name;
		data.vehicleIds = record.vehicleIds;
		data.userIds = record.userIds;
		if (record.phoneList) {
			data.enableMessage = '1';
		}
		data.notice = [];
		noticeOption.forEach(function(option) {
			if (record.options.findIndex(value => value === option.value) !== -1) {
				data.notice.push(option.value);
			}
		});
        
		data.subscribe = [];
		subscribeOption.forEach(function(option) {
			if (record.options.findIndex(value => value === option.value) !== -1) {
				data.subscribe.push(option.value);
			}
		});

		data.dateRange = [moment(record.startDate, 'yyyy-MM-DD'), moment(record.endDate, 'yyyy-MM-DD')];

		if (record.sendHour && record.sendMinute) {
			data.time = moment(record.sendHour + ':' + record.sendMinute, 'HH:mm');
		}
		form.setFieldsValue(data);
		onSubscribeChange();
	}
    
	function onDelete(key) {
		$.delete({
			url: `/admin/vehicle/work/message/${key}`,
			success: () => onClose(true)
		});
	}
    
	function handleData(data) {
		let obj = {};
		const [startDate, endDate] = data.dateRange;
		obj.name = data.name;
		obj.vehicleIds = data.vehicleIds;
		obj.userIds = data.userIds;
		obj.options = [];
		obj.startDate = startDate ? startDate.format('yyyy-MM-DD') : '';
		obj.endDate = endDate ? endDate.format('yyyy-MM-DD') : '';
		if (data.id) {
			obj.id = data.id;
		}
		if (data.subscribe) {
			obj.options= obj.options.concat(data.subscribe);
		}
		if (data.notice) {
			obj.options= obj.options.concat(data.notice);
		}
		if (data.enableMessage === '1' && data.userIds.length > 0) {
			let phoneArr = [];
			data.userIds.forEach(function(userId) {
				phoneArr.push(userMap.current[userId].phoneNumber);
			});
			obj.phoneList = phoneArr.join(';');
		}
		if (data.time) {
			obj.sendHour = data.time.format('HH');
			obj.sendMinute = data.time.format('mm');
		}

		return obj;
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				data = handleData(data);
				$.post({
					url: '/admin/vehicle/work/message',
					data,
					success: () => onClose(true)
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit.id;
				data = handleData(data);
				$.put({
					url: '/admin/vehicle/work/message',
					data,
					success: () => onClose(true)
				});
			});
		}
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 
    
	function toAdd() {
		setEdit(true);
		form.resetFields();
		setTimerVisible(false);
	}

	function onSubscribeChange() {
		setTimerVisible(form.getFieldValue('subscribe').length > 0);
	}

	return (
		<>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder='规则名称' enterButton onChange={e => setQuery(e.target.value)} onSearch={load} style={{ width: 300 }} value={query} />
					<Button type='primary' icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} pagination={data.pagination} columns={columns} dataSource={data.rows} rowSelection={{ type: 'checkbox' }} size='small' />
				</div>
			</div>
			<Modal
				title="新增规则"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={450}
			>
				<Form labelCol={{ span: 5 }} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="规则名称"
						name="name"
						rules={[{ required: true, message: '请输入规则名称' }]}
					>
						<Input placeholder="请输入规则名称"/>
					</Form.Item>
					<Form.Item
						label="选择车辆"
						name="vehicleIds"
						rules={[{ required: true, message: '请选择车辆' }]}
					>
						<TreeSelect placeholder="点击选择车辆" treeCheckable showCheckedStrategy="SHOW_CHILD" treeData={vehicleTreeData} showSearch/>
					</Form.Item>
					<Form.Item
						label="生效日期"
						name="dateRange"
						rules={[{ required: true, message: '请选择发送日期' }]}
					>
						<DatePicker.RangePicker style={{width: '100%'}}/>
					</Form.Item>
					<Form.Item
						label="实时提醒"
						name="notice"
					>
						<Checkbox.Group options={noticeOption} />
					</Form.Item>
					<Form.Item label="消息订阅" style={{marginBottom: 0}}>
						<Form.Item name="subscribe" style={{display: 'inline-block'}}>
							<Checkbox.Group onChange={onSubscribeChange} options={subscribeOption} />
						</Form.Item>
						{
							isTimerVisible
							&&
							<Form.Item name="time" style={{display: 'inline-block'}} rules={[{ required: true, message: '请选择推送时间' }]}>
								<TimePicker format="HH:mm" placeholder="推送时间"/>
							</Form.Item>
						}
					</Form.Item>
					<Form.Item
						label="帐号通知"
						name="userIds"
						rules={[{ required: true, message: '请选择通知用户' }]}
					>
						<TreeSelect placeholder="点击选择通知人" treeCheckable showCheckedStrategy="SHOW_CHILD" treeData={userTreeData} showSearch/>
					</Form.Item>
					<Form.Item
						label="短信提醒"
						name="enableMessage"
						initialValue="0" >
						<Radio.Group buttonStyle="solid">
							<Radio.Button value="0">关闭</Radio.Button>
							<Radio.Button value="1">开启</Radio.Button>
						</Radio.Group>
					</Form.Item>
				</Form>
			</Modal> 
		</>
	);
}