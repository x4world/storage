/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, DatePicker, Button, Popconfirm, Tooltip, Modal} from 'antd';
import IconFont from '../utils/IconFont';
import styles from './RolePage.less';
import {
	PlusOutlined
} from '@ant-design/icons';
import ProtocolEditPage from './ProtocolEditPage';
import $ from '../utils/CommonUtil';

export default function ProtocolPage() {
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [param, setParam] = useState('');
	const [dateRange, setDateRange] = useState(null);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 20
		}
	});
	const columns = [{
		title: '序号',
		render:(text,record,index)=>`${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '协议名称',
		dataIndex: 'name'
	}, {
		title: '版本号',
		dataIndex: 'version'
	}, {
		title: '创建人',
		dataIndex: 'creatorName'
	}, {
		title: '创建时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record.key)}><IconFont type="icon-edit"/></a></Tooltip>
				<Tooltip title="删除">
					<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Popconfirm>
				</Tooltip>
			</Space>
		)
	}];

	useEffect(load, []);

	function onEdit(key) {
		setEdit(key);
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/vehicle/parameter/table/${key}`,
			success: () => load()
		});
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/vehicle/parameter/table/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				param,
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			},
			fail: error => {
				Modal.error({
					title: '错误',
					content: error.description
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onRet() {
		setEdit(false);
		load();
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}

	return (
		<div className={styles.container} style={{overflowY: 'auto'}}>
			{
				!edit
				&&
				<>
					<div className={styles.header}>
						<Space>
							<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/>
							<Input.Search placeholder='请输入关键字查询' enterButton onChange={e => setParam(e.target.value)} onSearch={load} style={{width: 300}} value={param}/>
							<Button type='primary' icon={<PlusOutlined/>} onClick={() => setEdit(true)}>新增</Button>
						</Space>
					</div>
					<div className={styles.main}>
						<div className={styles.content}>
							<Table onChange={onTableChange} loading={loading} pagination={data.pagination} columns={columns} dataSource={data.rows} rowSelection={{type: 'checkbox'}} size='small'/>
						</div>
					</div>  
				</>
			} 
			{
				edit
				&&
				<ProtocolEditPage onRet={onRet} pid={edit === true ? null : edit}/>
			}
		</div>
	);
}