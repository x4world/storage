/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, DatePicker, Button} from 'antd';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';

export default function OperateLogPage() {
	const [loading, setLoading] = useState(false);
	const [dateRange, setDateRange] = useState(null);
	const [username, setUsername] = useState('');
	const [vehicleInfo, setVehicleInfo] = useState('');
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '操作账号',
		dataIndex: 'username'
	}, {
		title: '功能名称',
		dataIndex: 'process'
	}, {
		title: '操作时间',
		dataIndex: 'createTime'
	}, {
		title: '操作内容',
		dataIndex: 'content'
	}];

	useEffect(() => {
		load();
	}, []);

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/vehicle/production/log/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				param: username || vehicleInfo || '',
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}
    
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space size="large">
					<div>操作帐号：<Input onChange={e => setUsername(e.target.value)} style={{width: 250}}/></div>
					<div>车辆信息：<Input onChange={e => setVehicleInfo(e.target.value)} style={{width: 250}}/></div>
					<div>操作日期：<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/></div>
					<Button type="primary" onClick={() => load()}>查询</Button>
					<Button type="primary" href={`https://sc.xcmgzfl.com/xugongsuiche/admin/vehicle/production/log/export?param=${username || vehicleInfo || ''}&start=${dateRange ? dateRange[0].format('yyyy-MM-DD') : ''}&end=${dateRange ? dateRange[1].format('yyyy-MM-DD') : ''}`}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} size="small"/>
				</div>
			</div>  
		</div>
	);
}