/* eslint-disable react/display-name */
import React, {useEffect, useState} from 'react';
import { Table, Space, Input, Tree, Button, Tooltip, Modal, Form, TreeSelect, Popconfirm} from 'antd';
import IconFont from '../utils/IconFont';
import styles from './RolePage.less';
import commonStyles from './Common.less';
import $ from '../utils/CommonUtil';

import {
	DownOutlined,
	PlusOutlined
} from '@ant-design/icons';

export default function DeparementPage() {
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [form] = Form.useForm();
	const [departments, setDepartments] = useState([]);
	const [treeData, setTreeData] = useState([]);

	useEffect(() => {
		load();
	}, []); 
    
	const columns = [{
		title: '序号',
		render: (text,record,index) => `${index + 1}`
	}, {
		title: '所属组织',
		dataIndex: 'superName'
	}, {
		title: '组织名称',
		dataIndex: 'name'
	},  {
		title: '备注',
		dataIndex: 'remarks'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record.key)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];

	function load() {
		setLoading(true);

		$.get({
			url: '/admin/department/all',
			success: departments => {
				setLoading(false);
				
				const treeData = [];
				const map = {};
				
				departments.forEach(function(department) {
					const obj = {
						title: department.name,
						key: department.id,
						value: department.id
					};
					map[obj.key] = obj;
					if (department.superId) {
						const children = map[department.superId].children = map[department.superId].children || [];
						children.push(obj);
					} else {
						treeData.push(obj);
					}
				});
				setTreeData(treeData);

				departments.forEach(function(department) {
					department.key = department.id;
					if (department.superId) {
						department.superName = map[department.superId].title;
					}
				});
				setDepartments(departments);
			}
		});
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/department/${key}`,
			success: () => onClose(true)
		});
	}

	function onEdit(key) {
		setEdit(key);
		$.get({
			url: `/admin/department/${key}`,
			success: data => {
				form.setFieldsValue(data);
			}
		});
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				$.post({
					url: '/admin/department',
					data,
					success: () => onClose(true)
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit;
				$.put({
					url: '/admin/department',
					data,
					success: () => onClose(true)
				});
			});
		}
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 

	function toAdd() {
		setEdit(true);
		form.resetFields();
	}

	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="组织名称" enterButton onSearch={value => console.log(value)} style={{width: 300}}/>
					<Button type="primary" icon={<PlusOutlined/>} onClick={toAdd}>新增</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.sider}>
					<Tree
						switcherIcon={<DownOutlined />}
						treeData={treeData} 
						className={commonStyles.tree}/>
				</div>
				<div className={styles.content}>
					<Table loading={loading} columns={columns} dataSource={departments} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>   
			<Modal
				title="新增组织"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={450}
			>
				<Form labelCol={{ span: 5}} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="组织名称"
						name="name"
						rules={[{ required: true, message: '组织名称不能为空' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="所属组织"
						name="superId"
					>
						<TreeSelect treeData={treeData}/>
					</Form.Item>
					<Form.Item
						label="备注"
						name="remarks"
					>
						<Input.TextArea />
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}