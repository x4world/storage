/* eslint-disable react/display-name */
import React, {useState, useEffect, useRef} from 'react';
import { Table, Space, Input, Button, Modal, Form, Tooltip, Popconfirm, Radio, TreeSelect, DatePicker, TimePicker} from 'antd';
import moment from 'moment';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';
import {
	PlusOutlined
} from '@ant-design/icons';

export default function AnnouncementPage() {
	const userMap = useRef(null);
	const [form] = Form.useForm();
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [isTimerVisible, setTimerVisible] = useState(false);
	const [userTreeData, setUserTreeData] = useState(null);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '主题',
		dataIndex: 'name'
	}, {
		title: '消息类型',
		dataIndex: 'type',
		render: text => text === 'NOTICE' ? '通知' : '广告'
	}, {
		title: '发送方式',
		dataIndex: 'mode',
		render: mode => mode === 'INTIME' ? '及时' : '定时'
	}, {
		title: '创建人',
		dataIndex: 'creatorName'
	}, {
		title: '创建时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];
    
	useEffect(() => {
		$.get({
			url: '/admin/user/all',
			success: users => {
				$.get({
					url: '/admin/role/all',
					success: roles => {
						const map = {};
						const userTreeData = [];
						userMap.current = {};
						roles.forEach(function(role) {
							map[role.id] = [];
							userTreeData.push({
								title: role.name,
								value: 'r' + role.id,
								children: map[role.id]
							});
						});
						users.forEach(function(user) {
							map[user.roleId].push({
								title: user.realname,
								value: user.id
							});
							userMap.current[user.id] = user;
						});
						setUserTreeData(userTreeData);
					}
				});
			}
		});
		load();
	}, []);
    
	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/platform/message/page/${pagination.current}/${pagination.pageSize}`,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/platform/message/${key}`,
			success: () => onClose(true)
		});
	}

	function onEdit(record) {
		setEdit(record);
		if (record.sendTime) {
			record.date = moment(record.sendTime, 'yyyy-MM-DD');
			record.time = moment(record.sendTime, 'HH:mm');
		}
		form.setFieldsValue(record);
		onModeChange();
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				if (data.mode === 'FIXED') {
					data.sendTime = data.date.format('yyyy-MM-DD') + ' ' + data.time.format('HH:mm:ss');
				}
				$.post({
					url: '/admin/platform/message',
					data,
					success: () => onClose(true)
				});
			});
		} else {
			form.validateFields().then(data => {
				if (data.mode === 'FIXED') {
					data.sendTime = data.date.format('yyyy-MM-DD') + ' ' + data.time.format('HH:mm:ss');
				}
				data.id = edit.id;
				$.put({
					url: '/admin/platform/message',
					data,
					success: () => onClose(true)
				});
			});
		}
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 

	function toAdd() {
		setEdit(true);
		form.resetFields();
		setTimerVisible(false);
	}
    
	function onModeChange() {
		setTimerVisible(form.getFieldValue('mode') === 'FIXED');
	}
    
	return (
		<>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="主题" enterButton onSearch={value => console.log(value)} style={{width: 300}}/>
					<Button type="primary" icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>  
			<Modal
				title="添加公告"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={600}
			>
				<Form labelCol={{ span: 5 }} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="主题"
						name="name"
						rules={[{ required: true, message: '请输入主题' }]}
					>
						<Input placeholder="请输入主题" />
					</Form.Item>
					<Form.Item
						label="消息类型"
						name="type"
						initialValue="NOTICE"
					>
						<Radio.Group>
							<Radio value="NOTICE">通知</Radio>
							<Radio value="AD">广告</Radio>
						</Radio.Group>
					</Form.Item>
					<Form.Item label="发送方式" style={{marginBottom: 0}}>
						<Form.Item name="mode" style={{display: 'inline-block'}} initialValue="INTIME">
							<Radio.Group onChange={onModeChange} >
								<Radio value="INTIME">及时</Radio>
								<Radio value="FIXED">定时</Radio>
							</Radio.Group>
						</Form.Item>
						{
							isTimerVisible
                            &&
                            <>
                          	    <Form.Item name="date" style={{display: 'inline-block'}} rules={[{ required: true, message: '请选择日期' }]}>
                            		<DatePicker format="yyyy-MM-DD" placeholder="请选择日期"/>
                            	</Form.Item>
                            	<Form.Item name="time" style={{display: 'inline-block', marginLeft: 10}} rules={[{ required: true, message: '请选择时间' }]}>
                            		<TimePicker format="HH:mm" placeholder="请选择时间"/>
                            	</Form.Item>
                            </>
						}
					</Form.Item>
					<Form.Item
						label="帐号通知"
						name="userIds"
						rules={[{ required: true, message: '请选择通知用户' }]}
					>
						<TreeSelect placeholder="点击选择通知人" treeCheckable showCheckedStrategy="SHOW_CHILD" treeData={userTreeData} showSearch/>
					</Form.Item>
					<Form.Item
						label="内容"
						name="content"
						rules={[{ required: true, message: '请输入内容' }]}
					>
						<Input.TextArea rows={6}/>
					</Form.Item>
				</Form>
			</Modal> 
		</>
	);
}