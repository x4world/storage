/* eslint-disable react/prop-types */
/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, DatePicker, Button, Image, Modal} from 'antd';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';

function ImageDemo(props) {
	return (
		<Image.PreviewGroup>
			{
				props.record.vehiclePhoto
                &&
                <Image width={200} src={'https://heyi-photo.oss-cn-shanghai.aliyuncs.com' + props.record.vehiclePhoto}
                />
			}
			{
				props.record.mileagePhoto
                &&
                <Image width={200} src={'https://heyi-photo.oss-cn-shanghai.aliyuncs.com' + props.record.mileagePhoto}
                />
			}
		</Image.PreviewGroup>
	);
}

export default function HolidayPage() {
	const [isModalVisible, setIsModalVisible] = useState(false);
	const [record, setRecord] = useState(null);
	const [loading, setLoading] = useState(false);
	const [dateRange, setDateRange] = useState(null);
	const [username, setUsername] = useState('');
	const [plateNum, setPlateNum] = useState('');
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '车牌号',
		dataIndex: 'plateNum'
	}, {
		title: '车长姓名',
		dataIndex: 'realname'
	}, {
		title: '提报日期',
		dataIndex: 'createTime'
	}, {
		title: '提报地点',
		dataIndex: 'location'
	}, {
		title: '详情',
		render: (text,record) => <a href="javascript:;" onClick={() => showImage(record)}>图片</a>
	}];

	useEffect(() => {
		load();
	}, []);

	function handleOk() {
		setIsModalVisible(false);
	}
    
	function handleCancel() {
		setIsModalVisible(false);
	}
    
	function showImage(record) {
		setIsModalVisible(true);
		setRecord(record);
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/people/holiday/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				username,
				plateNum,
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}
    
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space size="large">
					<div>姓名：<Input onChange={e => setUsername(e.target.value)} style={{width: 250}}/></div>
					<div>车牌号：<Input onChange={e => setPlateNum(e.target.value)} style={{width: 250}}/></div>
					<div>日期：<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/></div>
					<Button type="primary" onClick={() => load()}>查询</Button>
					<Button type="primary" href={`https://sc.xcmgzfl.com/xugongsuiche/admin/people/holiday/export?username=${username}&plateNum=${plateNum}&start=${dateRange ? dateRange[0].format('yyyy-MM-DD') : ''}&end=${dateRange ? dateRange[1].format('yyyy-MM-DD') : ''}`}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} size="small"/>
				</div>
			</div> 
			<Modal title="图片" visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}>
				{record && <ImageDemo record={record}/>}
			</Modal> 
		</div>
	);
}