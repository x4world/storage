/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, DatePicker, Button, Radio, Popconfirm, Tooltip, Modal, Select, Form} from 'antd';
import IconFont from '../utils/IconFont';
import styles from './RolePage.less';
import {
	PlusOutlined
} from '@ant-design/icons';
import TemplateEditPage from './TemplateEditPage';
import $ from '../utils/CommonUtil';

export default function TemplatePage() {
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [param, setParam] = useState('');
	const [visible, setVisible] = useState(false);
	const [dateRange, setDateRange] = useState(null);
	const [protocols, setProtocols] = useState([]);
	const [tableId, setTableId] = useState(null);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	});
	const [tplType, setTplType] = useState('config');
	const columns = [{
		title: '序号',
		render:(text,record,index)=>`${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '模板ID',
		dataIndex: 'id'
	}, {
		title: '模板名称',
		dataIndex: 'name'
	}, {
		title: '车型代号',
		dataIndex: 'vehicleType'
	}, {
		title: '版本号',
		dataIndex: 'version'
	}, {
		title: '创建人',
		dataIndex: 'creatorName'
	}, {
		title: '创建时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record)}><IconFont type="icon-edit"/></a></Tooltip>
				<Tooltip title="删除">
					<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Popconfirm>
				</Tooltip>
			</Space>
		)
	}];

	useEffect(() => {
		load();
		$.get({
			url: '/admin/vehicle/parameter/table/all',
			success: protocols => setProtocols(protocols)
		});
	}, [tplType]);

	function onEdit(tpl) {
		setEdit(tpl);
	}

	function onDelete(key) {
		$.delete({
			url: `/api/tpl/${tplType}/${key}`,
			success: () => load()
		});
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/api/tpl/${tplType}/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				param,
				start: dateRange ? dateRange[0].format('yyyy-MM-DD') : '',
				end: dateRange ? dateRange[1].format('yyyy-MM-DD') : ''
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			},
			fail: error => {
				Modal.error({
					title: '错误',
					content: error.description
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onChange(e) {
		setTplType(e.target.value);
	}

	function onRet() {
		setEdit(false);
		load();
	}

	function onDateChange(dateRange) {
		setDateRange(dateRange);
	}

	function toAdd() {
		setVisible(true);
	}

	function onOK() {
		if (tableId) {
			setEdit(true);
			setVisible(false);
		} else {
			Modal.error({
				title: '错误',
				content: '请选择关联的协议'
			});
		}
	}

	return (
		<div className={styles.container} style={{overflowY: 'auto'}}>
			{
				!edit
				&&
				<>
					<div style={{marginBottom: 10}}>
						<Radio.Group value={tplType} buttonStyle='solid' onChange={onChange}>
							<Radio.Button value='config'>配置模板</Radio.Button>
							<Radio.Button value='set'>设置模板</Radio.Button>
						</Radio.Group>
					</div>
					<div className={styles.header}>
						<Space>
							<DatePicker.RangePicker onChange={onDateChange} value={dateRange}/>
							<Input.Search placeholder='请输入关键字查询' enterButton onChange={e => setParam(e.target.value)} onSearch={load} style={{width: 300}} value={param}/>
							<Button type='primary' icon={<PlusOutlined/>} onClick={toAdd}>新增</Button>
						</Space>
					</div>
					<div className={styles.main}>
						<div className={styles.content}>
							<Table onChange={onTableChange} loading={loading} pagination={data.pagination} columns={columns} dataSource={data.rows} rowSelection={{type: 'checkbox'}} size='small'/>
						</div>
					</div>  
				</>
			} 
			{
				edit
				&&
				<TemplateEditPage onRet={onRet} tplType={tplType} tpl={edit === true ? null : edit} tableId={tableId}/>
			}
			<Modal
				title="选择模板协议"
				centered
				visible={visible}
				onCancel={() => setVisible(false)}
				onOk={onOK}
				width={450}
			>
				<Form>
					<Form.Item label="通信协议">
						<Select onChange={value => setTableId(value)} value={tableId} showSearch optionFilterProp="children">
							{
								protocols.map(protocol => <Select.Option key={protocol.id} value={protocol.id}>{protocol.name + ' ' + protocol.version}</Select.Option>)
							}
						</Select>
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}