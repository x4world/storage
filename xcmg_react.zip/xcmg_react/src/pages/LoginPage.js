/* eslint-disable react/prop-types */
import React, {useState, useEffect} from 'react';
import styles from './LoginPage.less';
import IconFont from '../utils/IconFont';
import {Link} from 'react-router-dom';
import {Input, Button, Divider, Space, Form} from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import $ from '../utils/CommonUtil';

export default function LoginPage(props) {
	const [focus, setFocus] = useState(0);
	const [count, setCount] = useState(0);
	const [form] = Form.useForm();

	useEffect(() => {
		if (count > 0) {
			const id = setInterval(() => setCount(count => count - 1), 1000);
			return () => {clearInterval(id);};
		}
	}, [count]);

	function accountLogin(data) {
		$.post({
			url: '/api/login/username',
			data,
			success: data => {
				localStorage.setItem('m_token', data.token);
				props.history.push('/main');
			}
		});
	}

	function messageLogin(data) {
		$.post({
			url: '/api/login/mobile',
			data,
			success: data => {
				localStorage.setItem('m_token', data.token);
				props.history.push('/main');
			}
		});
	}

	function getCode() {
		const phoneNumber = form.getFieldValue('phoneNumber');
		if (phoneNumber) {
			$.get({
				url: '/api/login/mobile/' + phoneNumber,
				success: () => {
					
				}
			});
		}
	}

	return (
		<div className={styles.container}>
			<div className={styles.wrapper}>
				<div className={styles.header}>
					<div onClick={() => setFocus(0)} className={focus === 0 ? styles.focus : styles.title}>帐号登录</div>
					<div onClick={() => setFocus(1)} className={focus === 1 ? styles.focus : styles.title}>短信登录</div>
				</div>
				<div className={styles.main}>
					<div className={styles.scanBody} style={{ display: focus === 0 ? '' : 'none' }}></div>
					<div style={{ marginTop: 24 }}>
						<Form style={{ display: focus === 0 ? '' : 'none' }} onFinish={accountLogin}>
							<Form.Item
								name="username"
								rules={[{
									required: true,
									message: '请输入用户名'
								}]}>
								<Input
									size="large"
									prefix={<UserOutlined className={styles.formIcon} />}
									placeholder="用户名/手机"
								/>
							</Form.Item>
							<Form.Item
								name="password"
								rules={[{
									required: true,
									message: '请输入密码'
								}]}>
								<Input.Password
									size="large"
									prefix={<LockOutlined className={styles.formIcon} />}
									placeholder="密码"
								/>
							</Form.Item>
							<div className={styles.row}>
								<div></div>
								<a href="javascript:;">忘记密码？</a>
							</div>
							<Button type="primary" size="large" block htmlType="submit">登录</Button>
						</Form>
						<Form form={form} style={{ display: focus === 1 ? '' : 'none' }} onFinish={messageLogin}>
							<Form.Item
								name="phoneNumber"
								rules={[{
									required: true,
									message: '请输入手机号'
								}]}>
								<Input size="large"
									placeholder="手机号码"
									prefix={<IconFont type="icon-phone" className={styles.formIcon} />}
								/>
							</Form.Item>
							<Form.Item
								name="code"
								rules={[{
									required: true,
									message: '请输入手机验证码'
								}]}>
								<Space>
									<Input size="large"
										placeholder="手机验证码"
										prefix={<IconFont type="icon-code" className={styles.formIcon} />}
									/>
									<Button size="large" type="primary" onClick={getCode} disabled={count>0}>{count > 0 ? `重新发送(${count})` : '获取验证码'}</Button>
								</Space>
							</Form.Item>
							<Button type="primary" size="large" block htmlType="submit">登录</Button>
						</Form>
						<div className={styles.regRow}><Link to="/reg" style={{color: '#007EED'}}>立即注册</Link></div>
					</div>
				</div>
				<div className={styles.bottomFix}>
					<Divider style={{fontSize: 12}}>使用以下账号登录</Divider>
					<ul>
						<li><a href="javascript:;" className={styles.li}><IconFont type="icon-wechat"/><span className={styles.label}>微信</span></a></li>
					</ul>
				</div>
			</div>
		</div>
	);
}