import React from 'react';
import { Spin } from 'antd';
import styles from './MainPage.less';

export default function VehicleDataPage() {
	return <div className={styles.loading}><Spin tip="加载中..."/></div>;
}