/* eslint-disable react/prop-types */
import React, {useState, Suspense, useEffect} from 'react';
import { Layout, Menu, Space, Badge, Dropdown, Tabs, Spin, Popover } from 'antd';
import {Link} from 'react-router-dom';
import {
	MenuUnfoldOutlined,
	MenuFoldOutlined,
	BellOutlined,
	CaretDownOutlined,
	CloseCircleFilled
} from '@ant-design/icons';
import styles from './MainPage.less';
import $ from '../utils/CommonUtil';
const badgeStyle = {background: '#007EED', boxShadow: '0 0 0 1px #007EED'};
const { Header, Sider, Content } = Layout;

function MessageTab(props) {
	const tabs = [{
		label: '业务消息',
		msgs: props.bussinessNews
	}, {
		label: '公告消息',
		msgs: props.announcementNews
	}, {
		label: '故障消息',
		msgs: props.faultNews
	}];
	return (
		<div style={{width: 300}}>
			<Tabs defaultActiveKey="1">
				{
					tabs.map(tab => {
						return (
							<Tabs.TabPane tab={<div><Badge count={tab.msgs.length} style={badgeStyle} size="small">{tab.label}</Badge></div>} key={tab.label}>
								{
									tab.msgs.map((msg, index) => {
										return (
											<div className={styles.message} key={index}>
												<div className={styles.time}>{msg.createTime}</div>
												<div className={styles.messageContent}>{msg.message}</div>
											</div>
										);
									})
								}
							</Tabs.TabPane>
						);
					})
				}
			</Tabs>
			<div style={{display: 'flex', justifyContent: 'flex-end'}}>
				<a href="javascript:;" style={{fontSize: 12}} onClick={props.onViewAll}>查看全部</a>
			</div>
		</div>
	);
}

export default function MainPage(props) {
	const [collapsed, setCollapsed] = useState(false);
	const [activeKey, setActiveKey] = useState(null);
	const [defaultMenu, setDefaultMenu] = useState({
		openKeys: null,
		selectedKeys: null
	});
	const [tabs, setTabs] = useState([]);
	const [menus, setMenus] = useState([]);
	const [user, setUser] = useState(null);
	const [bussinessNews, setBussinessNews] = useState([]);
	const [announcementNews, setAnnouncementNews] = useState([]);
	const [faultNews, setFaultNews] = useState([]);
	useEffect(() => {
		$.get({
			url: '/api/user/info',
			success: data => {
				setUser(data);
				const set = new Set();
				data.nodes.forEach(function(node) {
					set.add(node.title);
				});

				const menus = [];
				$.nodes.forEach(function(node) {
					const obj = {
						title: node.title,
						icon: node.icon
					};

					if (node.children) {
						const children = [];
						node.children.forEach(function (child) {
							if (set.has(child.title)) {
								children.push({
									title: child.title,
									page: child.page
								});
							}
						});
						if (children.length > 0) {
							obj.children = children;
						}
					}

					if (obj.children) {
						menus.push(obj);
					}
				});
				setMenus(menus);

				if (menus.length > 0 && menus[0].children.length > 0) {
					addTab(menus[0].children[0]);
					setDefaultMenu({
						openKeys: menus[0].title,
						selectedKeys: menus[0].children[0].title
					});
				}
			},
			fail: () => window.location = '/login'
		});

		$.get({
			url: '/api/message/vehicle/work/new',
			success: data => {
				setBussinessNews(data);
			}
		});

		$.get({
			url: '/api/message/platform/new',
			success: data => {
				setAnnouncementNews(data);
			}
		});

		$.get({
			url: '/api/vehicle/fault/new',
			success: data => {
				setFaultNews(data);
			}
		});
	}, []);
	
	function toggle() {
		setCollapsed(!collapsed);
	}

	function addTab(tab) {
		tab.key = new Date().getTime() + '';
		const index = tabs.findIndex(item => item.page === tab.page);
		if (index !== -1) {
			tabs[index] = tab;
		} else {
			tabs.push(tab);
		}
		setTabs(tabs);
		setActiveKey(tab.key);
	}

	function onChange(activeKey) {
		setActiveKey(activeKey);
	}

	function onEdit(targetKey, action) {
		if (action === 'remove') {
			setTabs(tabs.filter(tab => tab.key !== targetKey));
		}
	}

	function logout() {
		localStorage.removeItem('m_token');
		props.history.push('/login');
	}

	function onViewAll() {
		addTab({title: '消息提醒', page: $.notifyPage});
	}

	return user ? (
		<Layout style={{height: '100%'}}>
			<Header className={styles.header} style={{padding: '0 24px'}}>
				<div className={styles.left}>
					<Link to="/"><img src="/images/logo.png" className={styles.logo}/></Link>
					<span style={{margin: '0 10px'}}>|</span>
					<span className={styles.banner}>随车智行管理系统平台</span>
				</div>
				<Space size="middle">
					<Popover placement="topRight" content={<MessageTab onViewAll={onViewAll} faultNews={faultNews} announcementNews={announcementNews} bussinessNews={bussinessNews}/>}>
						<a href="javascript:;" className={styles.white}><Badge count={bussinessNews.length + announcementNews.length + faultNews.length} style={badgeStyle}size="small"><BellOutlined/></Badge></a>
					</Popover>
					<Dropdown overlay={(
						<Menu>
							<Menu.Item>
								<Link onClick={logout}>退出系统</Link>
							</Menu.Item>
						</Menu>
					)}>
						<a href="javascript:;" className={styles.white}>{user.realname} <CaretDownOutlined /></a>
					</Dropdown>
				</Space>
			</Header>
			<Layout>
				<Sider trigger={null} collapsible collapsed={collapsed}>
					{
						defaultMenu.selectedKeys
						&&
						<Menu theme="dark" mode="inline" defaultSelectedKeys={[defaultMenu.selectedKeys]} defaultOpenKeys={[defaultMenu.openKeys]}>
							{
								menus.map(menu => {
									menu.items = menu.items || [];
									return (
										<Menu.SubMenu key={menu.title} icon={menu.icon} title={menu.title}>
											{
												menu.children.map(item => <Menu.Item key={item.title} onClick={() => addTab({title: item.title, page: item.page})}>{item.title}</Menu.Item>)
											}
										</Menu.SubMenu>
									);
								})
							}
						</Menu>
					}
				</Sider>
				<Content>
					<Tabs className={styles.tabs} onChange={onChange} activeKey={activeKey} onEdit={onEdit} tabBarStyle={{height: 40, display: 'flex', alignItems: 'center', background: '#334453', padding: '0 12px'}} type="editable-card" hideAdd tabBarExtraContent={{left: <div>{collapsed ? <MenuUnfoldOutlined onClick={toggle} className={styles.toggle}/> : <MenuFoldOutlined onClick={toggle} className={styles.toggle}/>}</div>}}>
						{
							tabs.map(tab => <Tabs.TabPane tab={tab.title} key={tab.key} closeIcon={<CloseCircleFilled style={{color: '#fff'}}/>} className={styles.content}><Suspense fallback={<div className={styles.loading}><Spin tip="加载中..."/></div>}>{tab.page && <tab.page/>}</Suspense></Tabs.TabPane>)
						}
					</Tabs>
				</Content>
			</Layout>
		</Layout>
	) : null;
}