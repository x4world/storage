/* eslint-disable react/display-name */
import React, {useState, useEffect, useRef} from 'react';
import { Table, Space, Input, DatePicker, Button} from 'antd';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';

export default function AttendancePage() {
	const [loading, setLoading] = useState(false);
	const [range, setRange] = useState([]);
	const [username, setUsername] = useState('');
	const [wxphone, setWxphone] = useState('');
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 
	const urlRef = useRef('/admin/people/data/today');

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '姓名',
		dataIndex: 'realname'
	}, {
		title: '手机号码',
		dataIndex: 'wxphone'
	}, {
		title: '打卡号码',
		dataIndex: 'wxphone'
	}, {
		title: '车辆/用户信息',
		dataIndex: 'info'
	}, {
		title: '第几天',
		dataIndex: 'theDay'
	}, {
		title: '备注',
		dataIndex: 'comment'
	}, {
		title: '打卡时间',
		dataIndex: 'createTime',
		render: text => (!text || new Date(text).getHours() >= 9) ? <div style={{color: 'white', background: 'red', height: 25}}>{text}</div> : text
	}, {
		title: '打卡地点',
		dataIndex: 'location'
	}];

	useEffect(() => {
		load();
	}, []);

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `${urlRef.current}/page/${pagination.current}/${pagination.pageSize}`,
			data: {
				username,
				wxphone,
				start: range[0],
				end: range[1]
			},
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.phoneNumber;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDateChange(dateRange) {
		range[0] = dateRange[0].format('yyyy-MM-DD');
		range[1] = dateRange[1].format('yyyy-MM-DD');
		setRange(range);
	}
    
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space size="large">
					<div>姓名：<Input onChange={e => setUsername(e.target.value)} style={{width: 250}}/></div>
					<div>手机：<Input onChange={e => setWxphone(e.target.value)} style={{width: 250}}/></div>
					<div>日期：<DatePicker.RangePicker onChange={onDateChange}/></div>
					<Button type="primary" onClick={() => {urlRef.current = '/admin/people/data';load();}}>查询</Button>
					<Button type="primary" href={`https://sc.xcmgzfl.com/xugongsuiche${urlRef.current}/export?username=${username}&wxphone=${wxphone}&start=${range[0]}&end=${range[1]}`}>导出</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} size="small"/>
				</div>
			</div>  
		</div>
	);
}