import React, {useState, useRef, useEffect} from 'react';
import {Input, Checkbox, Tree, Space, Select, Button, Tooltip, Divider, Popover, Table} from 'antd';
import IconFont from '../utils/IconFont';
import styles from './VehicleMonitorPage.less';
import commonStyles from './Common.less';
import {
	DownOutlined,
	PlusOutlined,
	MinusOutlined
} from '@ant-design/icons';
import $ from '../utils/CommonUtil';

const labelStyle = {
	color : '#fff',
	display: 'flex',
	flexDirection: 'column',
	justifyContent: 'center',
	alignItems: 'center',
	fontSize : '12px',
	height : '70px',
	width: '70px',
	fontFamily: '微软雅黑',
	background: 'transparent url(/images/marker_bg.png) no-repeat',
	backgroundSize: '100% 100%',
	border: 'none'
};

const vehicleColumns = [{
	title: '序号',
	dataIndex: 'index'
}, {
	title: '分组',
	dataIndex: 'group'
}, {
	title: '车辆类型',
	dataIndex: 'category'
}, {
	title: '车牌号',
	dataIndex: 'plateNum'
}, {
	title: '终端编号',
	dataIndex: 'terminalCode'
}, {
	title: '车辆代号',
	dataIndex: 'vehicleNum'
}, {
	title: '出厂编号',
	dataIndex: 'productNum'
}, {
	title: 'VIN码',
	dataIndex: 'vin'
}];

const vehicleData = [{
	index: 1,
	group: '生产',
	category: '高空车',
	plateNum: '苏C10086',
	terminalCode: 'DG2010086',
	vehicleNum: '17',
	productNum: 'GKS18A123467',
	vin: 'VIN1234',
}];

const treeModes = [
	{key: 'group', title:'分组'},
	{key: 'area', title:'分区'},
	{key: 'type', title:'车型'},
	{key: 'temp', title:'临时'}
];

const STATUS_ALL = 0;
const STATUS_WORK = 1;
const STATUS_WAIT = 2;
const STATUS_OFFLINE = 3;

export default function VehicleMonitorPage() {
	const containerRef = useRef(null);
	const mapContainer = useRef(null);
	const mapRef = useRef(null);
	const distanceToolRef = useRef(null);
	const serviceManRef = useRef(null);
	const groupRef = useRef(null);
	const [vehicles, setVehicles] = useState(null);
	const [checkedKeys, setCheckedKeys] = useState([]);
	const [expandedKeys, setExpandedKeys] = useState(['top']);
	const [showTree, setShowTree] = useState(true);
	const [showBottom, setShowBottom] = useState(false);
	const [satelliteMode, setSatelliteMode] = useState(false);
	const [measureMode, setMeasureMode] = useState(false);
	const [findCarMode, setFindCarMode] = useState(false);
	const [collectMode, setCollectMode] = useState(true);
	const [fullScreenMode, setFullScreenMode] = useState(false);
	const [treeMode, setTreeMode] = useState('group');
	const [treeData, setTreeData] = useState(null);
	const [filterStatus, setFiterStatus] = useState(STATUS_ALL);
	const [zoomMode, setZoomMode] = useState('province');
	const [serviceManMode, setServiceManMode] = useState(false);
	const [servicePlaceMode, setServicePlaceMode] = useState(false);
	const [detailMode, setDetailMode] = useState(false);
	const [alarmMode, setAlarmMode] = useState(false);
	const [searchKey, setSearchKey] = useState(null);
	const [focus, _setFocus] = useState(null);
	const [stat] = useState({
		statusStat: [
			{title: '全部', status: STATUS_ALL, count: 0},
			{title: '工作', status: STATUS_WORK, count: 0},
			{title: '停机', status: STATUS_WAIT, count: 0},
			{title: '离线', status: STATUS_OFFLINE, count: 0}
		]
	});

	useEffect(() => {
		const BMapGL = window.BMapGL;
		const map = mapRef.current = new BMapGL.Map(mapContainer.current);
		distanceToolRef.current = new window.BMapGLLib.DistanceTool(map);
		map.enableDragging();
		map.enableScrollWheelZoom(true);
		zoomToCenter();
		map.addEventListener('zoomend', onZoomEnd);
		map.addEventListener('moving', onMoving);
		map.addEventListener('zoomstart', onZoomStart);


		$.get({
			url: '/api/vehicle',
			success: data => {
				let vehicles = {};
				data.forEach(function(vehicle, index) {
					let iconStr = '', status = '';
					const key = 'v' + index;
					vehicle.displayName = vehicle.productNum;
					vehicles[key] = vehicle;
					var category = vehicle.category;
					if (category === 'QJ') {
						category = '桥检车';
						iconStr += 'qjc_';
					} else if (category === 'FW') {
						category = '服务车';
						iconStr += 'fwc_';
					} else if (category === 'GK') {
						category = '高空车';
						iconStr += 'gkc_';
					} else {
						category = '未知车型';
					}
					
					if (vehicle.onlineStatus === 0) {
						status = STATUS_OFFLINE;
						stat.statusStat[3].count++;
						iconStr += 'offline';
					} else {
						if (vehicle.acc === 1) {
							status = STATUS_WORK;
							stat.statusStat[1].count++;
							iconStr += 'work';
						} else {
							status = STATUS_WAIT;
							stat.statusStat[2].count++;
							iconStr += 'wait';
						}
					}

					vehicle.status = status;
					vehicle.icon = <img src={`/images/${iconStr}.png`}/>;
					vehicle.icon2 = `/images/${iconStr}_m.png`;
					vehicle.key = key;

				});

				
				setVehicles(vehicles);
			}
		});

		$.get({
			url: '/api/debug/getAll',
			success: data => {
				/*data.vehicles.forEach(function(data, index) {
					let status, category, iconStr = '';

					if (data[2] === 1) {
						category = '桥检车';
						iconStr += 'qjc_';
					} else if (data[2] === 2) {
						category = '服务车';
						iconStr += 'fwc_';
					} else if (data[2] === 3) {
						category = '高空车';
						iconStr += 'gkc_';
					} else {
						category = '未知车型';
					}

					if (!data[3]) {
						data[3] = '未知车型';
					}

					if (data[8] === 0) {
						status = STATUS_OFFLINE;
						stat.statusStat[3].count++;
						iconStr += 'offline';
					} else {
						if (data[7] === 1) {
							status = STATUS_WORK;
							stat.statusStat[1].count++;
							iconStr += 'work';
						} else {
							status = STATUS_WAIT;
							stat.statusStat[2].count++;
							iconStr += 'wait';
						}
					}
					stat.statusStat[0].count++;

					const key = 'v' + index;
					vehicles[key] = {
						productNum: data[0],
						terminalCode: data[1],
						category,
						vehicleType: data[3],
						province: data[4],
						city: data[5],
						groupid: data[6],
						icon: <img src={`/images/${iconStr}.png`}/>,
						icon2: `/images/${iconStr}_m.png`, 
						status,
						isOnline: data[8],
						longitude: data[9],
						latitude: data[10],
						plateNum: data[11],
						displayName: data[11] || data[0] || data[1],
						key
					};
				});*/
				groupRef.current = [
					['XGSC', '徐工随车', null], 
					['PRODUCE', '生产组', 'XGSC'], 
					['CHECK', '检测组', 'XGSC'], 
					['LAUNCH', '发车组', 'XGSC'], 
					['SALE', '销售组', 'XGSC']
				];
				serviceManRef.current = data.peoples;
			}
		});
	}, []);

	function zoomToCenter() {
		const BMapGL = window.BMapGL;
		mapRef.current.centerAndZoom(new BMapGL.Point(108.2115, 30.423), 5);
	}

	function onZoomStart() {
		const point = mapRef.current.focusPoint;
		setFocus(null);
		mapRef.current.focusPoint = point;
	}

	function onZoomEnd() {
		const zoom = Math.round(mapRef.current.getZoom());
		let zoomMode = null;
		if (zoom < 8) {
			zoomMode = 'province';
		} else if (zoom >= 8 && zoom <= 10) {
			zoomMode = 'city';
		} else {
			zoomMode = 'detail';
		}
		setZoomMode(zoomMode);

		const point = mapRef.current.focusPoint;
		if (point) {
			setFocus(point);
		} 
	}

	function onVehicleClick() {
		setFocus(this.getPosition());
	}

	function onServiceManClick() {

	}

	function onMoving() {
		const point = mapRef.current.focusPoint;
		if (point) {
			setFocus(point);
		}
	}

	useEffect(() => {
		let filterVehicles = [];
		const checkedKeys = [];
		let regexp = null;
		if (searchKey) {
			regexp = new RegExp(searchKey);
		}
		for (var key in vehicles) {
			const vehicle =  vehicles[key];
			if (searchKey) {
				if (regexp.test(vehicle.productNum) || regexp.test(vehicle.plateNum) || regexp.test(vehicle.terminalCode)) {
					filterVehicles.push(vehicle);
					checkedKeys.push(key);
				}
			} else {
				if (filterStatus === STATUS_ALL || vehicle.status === filterStatus) {
					filterVehicles.push(vehicle);
					checkedKeys.push(key);
				}
			}
		}

		if (treeMode === 'group') {
			showVehiclesByGroup(filterVehicles);
		} else if (treeMode === 'area') {
			showVehiclesByArea(filterVehicles);
		} else if (treeMode === 'type') {
			showVehiclesByType(filterVehicles);
		}

		setCheckedKeys(checkedKeys);
	}, [treeMode, filterStatus, vehicles, searchKey]);

	useEffect(() => {
		if (satelliteMode) {
			mapRef.current.setMapType(window.BMAP_EARTH_MAP);
		} else {
			mapRef.current.setMapType(window.BMAP_NORMAL_MAP);
		}
	}, [satelliteMode]);

	useEffect(() => {
		if (measureMode) {
			distanceToolRef.current.open();
		} else {
			distanceToolRef.current.close();
		}
	}, [measureMode]);

	useEffect(() => {
		const BMapGL = window.BMapGL;
		const map = mapRef.current;
		map.clearOverlays();     
		let filterVehicles = [];
		if (checkedKeys.length > 0) {
			checkedKeys.forEach(key => {
				const vehicle = vehicles[key];
				if (vehicle) {
					filterVehicles.push(vehicle);
				}
			});
		} else {
			/*for (let key in vehicles) {
				const vehicle = vehicles[key];
				
				if (filterStatus === STATUS_ALL || vehicle.status === filterStatus) {
					filterVehicles.push(vehicle);
				}
			}*/
		}

		if (serviceManMode) {
			serviceManRef.current.forEach(function(people) {
				console.log(people);
				const point = new BMapGL.Point(people.longitude, people.latitude);
				const marker = new BMapGL.Marker(point, {
					icon: new BMapGL.Icon('/images/serviceman.png', new BMapGL.Size(26, 30))
				});
				marker.addEventListener('click', onServiceManClick);
				map.addOverlay(marker);
			}); 
		}

		if (!collectMode || zoomMode === 'detail') {
			filterVehicles.forEach(vehicle => {
				if (vehicle.longitude && vehicle.latitude) {
					const point = new BMapGL.Point(vehicle.longitude, vehicle.latitude);
					const marker = new BMapGL.Marker(point, {
						icon: new BMapGL.Icon(vehicle.icon2, new BMapGL.Size(26, 30))
					});
					marker.addEventListener('click', onVehicleClick);
					map.addOverlay(marker);
				}
			});
		} else {
			let areaMap = {};
			filterVehicles.forEach(vehicle => {
				if (zoomMode === 'province') {
					if (vehicle.province) {
						let name = vehicle.province.replace(/[省市(自治区)]/g, '');
						if (name.length > 3) {
							name = name.substring(0, 2);
						}
						let obj = areaMap[name];
						if (!obj) {
							obj = areaMap[name] = {
								count: 0,
								point: new BMapGL.Point(vehicle.longitude, vehicle.latitude)
							};
						} 
						obj.count++;
					}
				} else if (zoomMode === 'city') {
					if (vehicle.city) {
						let name = vehicle.city;
						let obj = areaMap[name];
						if (!obj) {
							obj = areaMap[name] = {
								count: 0,
								point: new BMapGL.Point(vehicle.longitude, vehicle.latitude)
							};
						} 
						obj.count++;
					}
				}
			});

			for (let title in areaMap) {
				const obj = areaMap[title];
				const label = new BMapGL.Label(`<div>${title}</div><div>${obj.count}</div>`, {
					position: obj.point
				});  
				label.setStyle(labelStyle);
				map.addOverlay(label);  
			}	
		}
	}, [collectMode, checkedKeys, zoomMode, vehicles, serviceManMode]);

	function showVehiclesByGroup(vehicles) {
		let data = [];
		let gmap = {};
		const groups = groupRef.current;
		if (groups) {
			groups.forEach(function (arr) {
				const groupid = arr[0];
				const name = arr[1];
				const parent = arr[2];
				const node = {
					title: name,
					key: groupid,
					children: []
				};
				if (!parent) {
					data.push(node);
				} else {
					gmap[parent].children.push(node);
				}
				gmap[groupid] = node;
			});
			vehicles.forEach(function (vehicle) {
				const group = gmap[vehicle.group];
				if (group) {
					group.children.push({
						title: vehicle.displayName,
						icon: vehicle.icon,
						key: vehicle.key
					});
				}
			});
			setTreeData(data);
		}
	}

	function showVehiclesByArea(vehicles) {
		let provinces = {};
		vehicles.forEach(function (vehicle) {
			const { province, city } = vehicle;
			if (province && city) {
				let citys = provinces[province];
				if (!citys) {
					citys = provinces[province] = {};
				}

				let vehicles = citys[city];
				if (!vehicles) {
					vehicles = citys[city] = [];
				}
				vehicles.push({
					title: vehicle.displayName,
					icon: vehicle.icon,
					key: vehicle.key
				});
			}
		});

		let data = [];
		for (let province in provinces) {
			let children = [];
			let total = 0;
			if (province !== '北京市' && province !== '上海市' && province !== '天津市' && province !== '重庆市' ) {
				const citys = provinces[province];
				for (let city in citys) {
					let count = citys[city].length;
					children.push({
						title: `${city}(${count})`,
						key: city,
						children: citys[city]
					});
					total += count;
				}
				children.sort((a, b) => a.title.localeCompare(b.title));
			} else {
				children = provinces[province][province];
				total += children.length;
			}
			data.push({
				title: `${province}(${total})`,
				key: province,
				children
			});
			
		}
		setTreeData([{
			title: '全国',
			key: 'top',
			children: data
		}]);
	}

	function showVehiclesByType(vehicles) {
		let map = {};
		vehicles.forEach(function (vehicle) {
			const { category, vehicleType } = vehicle;
			if (category && vehicleType) {
				if (category === '服务车') {
					const vehicles = map[category] = map[category] || [];
					vehicles.push({
						title: vehicle.displayName,
						icon: vehicle.icon,
						key: vehicle.key
					});
				} else {
					let vehicleTypes = map[category];
					if (!vehicleTypes) {
						vehicleTypes = map[category] = {};
					}

					let vehicles = vehicleTypes[vehicleType];
					if (!vehicles) {
						vehicles = vehicleTypes[vehicleType] = [];
					}
					vehicles.push({
						title: vehicle.productNum || '',
						icon: vehicle.icon,
						key: vehicle.key
					});
				}
			}
		});

		let data = [];
		for (let category in map) {
			let children = [];
			let total = 0;
			if (category === '服务车') {
				children = map[category];
				total += children.length;
			} else {
				const vehicleTypes = map[category];
				for (let vehicleType in vehicleTypes) {
					let count = vehicleTypes[vehicleType].length;
					children.push({
						title: `${vehicleType}(${count})`,
						key: category + '-' + vehicleType,
						children: vehicleTypes[vehicleType]
					});
					total += count;
				}
			}
			data.push({
				title: `${category}(${total})`,
				key: category,
				children
			});
			children.sort((a, b) => a.title.localeCompare(b.title));
			
		}
		setTreeData([{
			title: '所有车型',
			key: 'top',
			children: data
		}]);
	}

	function onExpand(expandedKeys) {
		setExpandedKeys(expandedKeys);
	}

	function toggleAlarmMode() {
		setAlarmMode(!alarmMode);
	}

	function toggleServiceManMode() {
		setServiceManMode(!serviceManMode);
	}

	function toggleServicePlaceMode() {
		setServicePlaceMode(!servicePlaceMode);
	}

	function toggleDetailMode() {
		setDetailMode(!detailMode);
	}

	function toggleSatelliteMode() {
		setSatelliteMode(!satelliteMode);
	}

	function toggleFullScreenMode() {
		setFullScreenMode(!fullScreenMode);
	}

	function toggleFindCarMode() {
		setFindCarMode(!findCarMode);
	}

	function toggleMeasureMode() {
		setMeasureMode(!measureMode);
	}

	function toggleCollectMode() {
		setCollectMode(!collectMode);
	}

	function toggleTree() {
		setShowTree(!showTree);
	}

	function toggleBottom() {
		setShowBottom(!showBottom);
	}

	function onCheck(checkedKeys) {
		setCheckedKeys(checkedKeys);
	}

	function onSearch(value) {
		setSearchKey(value);
	}

	function onClose() {
		setFocus(null);
	}

	function setFocus(point) {
		const map = mapRef.current;
		if (point) {
			map.focusPoint = point;
			point = map.pointToOverlayPixel(point);
			point.x -= 158;
			point.y -= 270;
		}  else {
			map.focusPoint = null;
		}
		_setFocus(point);
	}

	function onSelect(selectedKeys) {
		if (selectedKeys.length > 0) {
			const key = selectedKeys[0];
			const vehicle = vehicles[key];
			if (vehicle) {
				const point = new window.BMapGL.Point(vehicle.longitude, vehicle.latitude);
				mapRef.current.focusPoint = point;
				mapRef.current.centerAndZoom(point, 15);
			}
		} else {
			zoomToCenter();
			setFocus(null);
		}
	}

	return (
		<div className={fullScreenMode ? styles.containerFullScreen : styles.container} ref={containerRef}>
			<div ref={mapContainer} className={styles.map}></div>
			{
				focus
				&&
				<div className={styles.popup} style={{left: focus.x, top: focus.y}}>
					<div className={styles.con}>
						<div className={styles.conHeader}>
							<div className={styles.left}>
								<IconFont type="icon-vehicle"/>
								<div style={{color: '#3DFF01', marginTop: 2}}>在线</div>
							</div>
							<div className={styles.right}>
								<div className={styles.rightTitle}>晋AE3122</div>
								<div className={styles.rightMore}>
									<span>详细<IconFont type="icon-more"/></span>
									<IconFont onClick={onClose} type="icon-close" style={{color: '#B4D6F6', cursor: 'pointer', marginLeft: 2, fontSize: 14}}/>
								</div>
							</div>
						</div>
						<div className={styles.conBody}>
							<div>行驶速度：42km/h{focus.speed}</div>
							<div>定位：已定位</div>
							<div>更新时间：2020-11-29 12:31{focus.gpsTime}</div>
							<div>定位位置：福建省厦门市思明区环岛南路3999号{focus.location}</div>
						</div>
						<div className={styles.conFooter}>
							<Tooltip title="周边" color="#585E6A"><IconFont type="icon-zhoubian" style={{color: '#B4D6F6', cursor: 'pointer'}}/></Tooltip>
							<Tooltip title="追踪" color="#585E6A"><IconFont type="icon-zhuizong" style={{color: '#B4D6F6', cursor: 'pointer'}}/></Tooltip>
							<Tooltip title="轨迹" color="#585E6A"><IconFont type="icon-guiji" style={{color: '#B4D6F6', cursor: 'pointer'}}/></Tooltip>
							<Tooltip title="参数" color="#585E6A"><IconFont type="icon-canshu" style={{color: '#B4D6F6', cursor: 'pointer'}}/></Tooltip>
						</div>
					</div>
					<div className={styles.ret}/>
				</div>
			}
			<div className={showTree ? styles.siderIn : styles.siderOut}>
				<div className={styles.top}>
					<div className={styles.title}>车辆列表</div>
					<Input.Search placeholder="请输入搜索车辆" onSearch={onSearch} />
					<div className={styles.groups}>
						{
							treeModes.map(
								mode => <Checkbox key={mode.key} className={styles.checkbox} onClick={() => setTreeMode(mode.key)} checked={treeMode === mode.key}>{mode.title}</Checkbox>
							)
						}
					</div>
				</div>
				<ul className={styles.middle}>
					{
						stat.statusStat.map(
							item => <li key={item.status} className={filterStatus === item.status ? styles.checked : ''} onClick={() => setFiterStatus(item.status)}>{item.title}<br />({item.count})</li>
						)
					}
				</ul>
				<div className={styles.bottom}>
					<Tree
						checkable
						showIcon
						expandedKeys={expandedKeys}
						checkedKeys={checkedKeys}
						switcherIcon={<DownOutlined />}
						treeData={treeData}
						onExpand={onExpand}
						onSelect={onSelect}
						className={commonStyles.tree}
						onCheck={onCheck} />
				</div>
			</div>
			<div className={showBottom ? styles.siderUp : styles.siderDown}>
				<div className={styles.bottomBar}>
					<div className={styles.bottomLeft}>
						<Tooltip placement="topLeft" title={showTree ? '收起' : '车辆列表'}><div className={styles.bottomLeftBtn} onClick={toggleTree}><IconFont type={showTree ? 'icon-back' : 'icon-tree'}/></div></Tooltip>
						{
							stat.statusStat.map(
								item => <div key={item.status} className={filterStatus === item.status ? styles.bottomBtnFocus: styles.bottomLeftBtn} onClick={() => setFiterStatus(item.status)}>{item.title}({item.count})</div>
							)
						}
						<Popover overlayClassName={styles.help} content="工作:  车辆正在正常行驶中,您可以查看车辆的速度、位置。" title="车辆实时状态说明" trigger="click"><div className={styles.bottomLeftBtn}><IconFont type="icon-help"/></div></Popover>
					</div>
					<div className={styles.bottomRight}>
						<Space size="large">
							<div className={styles.bottomBtn}><IconFont type="icon-download"/></div>
							<div className={styles.bottomBtn} onClick={toggleBottom}><IconFont type={showBottom ? 'icon-down' : 'icon-up'}/></div>
						</Space>
					</div>
				</div>
				<div className={styles.bottomContent}>
					<Space style={{padding: 10}}>
						<Select placeholder="请选择" style={{ width: 200 }}>
							<Select.Option value="jack">Jack</Select.Option>
							<Select.Option value="lucy">Lucy</Select.Option>
							<Select.Option value="disabled" disabled>Disabled</Select.Option>
							<Select.Option value="Yiminghe">yiminghe</Select.Option>
						</Select>
						<Input placeholder="请输入搜索内容" style={{ width: 200 }}></Input>
						<Button type="primary">查询</Button>
					</Space>
					<Table columns={vehicleColumns} dataSource={vehicleData} size="small"/>
				</div>
			</div>
			<div className={styles.topBar}>
				<div className={serviceManMode ? styles.focus : styles.normal} onClick={toggleServiceManMode}><IconFont type="icon-man" style={{color: '#1E90FD'}}/> 服务人员</div>
				<div className={servicePlaceMode ? styles.focus : styles.normal} onClick={toggleServicePlaceMode}><IconFont type="icon-fuwuzhan" style={{color: '#1E90FD'}}/> 服务站</div>
				<div className={detailMode ? styles.focus : styles.normal} onClick={toggleDetailMode}><IconFont type="icon-vehicle-info" style={{color: '#1E90FD'}}/> 车辆信息</div>
			</div>
			<div className={styles.rightBar}>
				<div className={findCarMode ? styles.focus2 : styles.normal2} onClick={toggleFindCarMode}><IconFont type="icon-search" style={{color: '#1E90FD'}}/>&nbsp;&nbsp;找车</div>
				<Divider style={{margin: 0}}/>
				<div className={measureMode ? styles.focus2 : styles.normal2} onClick={toggleMeasureMode}><IconFont type="icon-measure" style={{color: '#1E90FD'}}/>&nbsp;&nbsp;测距</div>
				<Divider style={{margin: 0}}/>
				<div className={alarmMode ? styles.focus2 : styles.normal2} onClick={toggleAlarmMode}><IconFont type="icon-alarm" style={{color: '#1E90FD'}}/> &nbsp;&nbsp;报警</div>
				<Divider style={{margin: 0}}/>
				<div className={collectMode ? styles.focus2 : styles.normal2} onClick={toggleCollectMode}><IconFont type="icon-collect" style={{color: '#1E90FD'}}/> &nbsp;&nbsp;聚合</div>
			</div>
			{
				findCarMode
				&&
				<div className={styles.findCarContainer}>
					<div className={styles.findCarHeader}>在地图范围内搜索</div>
					<div className={styles.findCarBody}>
						<Input.Search placeholder="格式:XX市XX,例:南京市宁双路" onSearch={value => console.log(value)} enterButton />
					</div>
				</div>
			}
			<div className={styles.btns}>
				<a href="javascript:;" className={styles.btn} style={{marginBottom: 6}} onClick={toggleSatelliteMode}>{satelliteMode ? '平面' : '卫星'}</a>
				<a href="javascript:;" className={styles.btn} style={{marginBottom: 6}} onClick={toggleFullScreenMode}><IconFont type={fullScreenMode ? 'icon-compress' : 'icon-fullscreen'} style={{fontSize: 16}}/></a>
				<div className={styles.btn2}>
					<a href="javascript:;" onClick={() => mapRef.current.zoomIn()}><PlusOutlined/></a>
					<Divider style={{margin: 0}}/>
					<a href="javascript:;" onClick={() => mapRef.current.zoomOut()}><MinusOutlined/></a>
				</div>
			</div>
		</div>
	);
}