/* eslint-disable react/display-name */
import React, {useEffect, useState, useRef} from 'react';
import { Table, Space, Input, Tree, Button, Tooltip, Modal, Form, Popconfirm, Row, Col, TreeSelect} from 'antd';
import styles from './RolePage.less';
import commonStyles from './Common.less';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import {
	DownOutlined,
	PlusOutlined
} from '@ant-design/icons';


export default function RolePage() {
	const [edit, setEdit] = useState(false);
	const [form] = Form.useForm();
	const [nodes, setNodes] = useState(null);
	const [authorities, setAuthorities] = useState(null);
	const [loading, setLoading] = useState(false);
	const [checkedNodes, setCheckedNodes] = useState([]);
	const [checkedAuthorities, setCheckedAuthorities] = useState([]);
	const [checkedGroups, setCheckedGroups] = useState([]);
	const [departments, setDepartments] = useState([]);
	const allMap = useRef({});
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	});
	const groups = [{
		title: '分组',
		key: 'group',
		children: [
			{title: '生产组', key: 'PRODUCE'},
			{title: '检测组', key: 'CHECK'},
			{title: '发车组', key: 'LAUNCH'},
			{title: '销售组', key: 'SALE'},
			{title: '客服中心', key: 'AFTER_SALE'}
		]
	}];
	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '角色名称',
		dataIndex: 'name'
	}, {
		title: '所属部门',
		dataIndex: 'departmentId',
		render: text => allMap.current[text]
	}, {
		title: '创建时间',
		dataIndex: 'createTime'
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record.key)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];
    
	useEffect(() => {
		$.get({
			url: '/admin/department/all',
			success: data => {
				const departments = [];
				const map = {};
				allMap.current = {};
				data.forEach(function(department) {
					const obj = {
						title: department.name,
						key: department.id,
						value: department.id
					};
					if (department.superId) {
						const children = map[department.superId].children = map[department.superId].children || [];
						children.push(obj);
					} else {
						map[obj.key] = obj;
						departments.push(obj);
					}
					allMap.current[department.id] = department.name;
				});
				setDepartments(departments);
				load();
			}
		});
	}, []);

	useEffect(() => {
		if (edit) {
			$.get({
				url: '/admin/node/all',
				success: data => {
					const nodes = [];
					const map = {};
					data.forEach(function (node) {
						map[node.title] = node.id;
					});
					$.nodes.forEach(function (node) {
						const id = map[node.title];
						if (!id) {
							return;
						}
						const obj = {
							title: node.title,
							key: id
						};
						if (node.children) {
							const children = obj.children = [];
							node.children.forEach(function (node) {
								const id = map[node.title];
								if (!id) {
									return;
								}
								children.push({
									title: node.title,
									key: id
								});
							});
							obj.children = children;
						}
						nodes.push(obj);
					});
					setNodes(nodes);
				}
			});

			$.get({
				url: '/admin/authority/all',
				success: data => {
					const authorities = [];
					data.forEach(function(authority) {
						authorities.push({
							title: authority.title,
							key: authority.value
						});
					});
					setAuthorities([{
						title: '权限管理',
						key: '权限管理',
						children: authorities
					}]);
				}
			});
		}
	}, [edit]);

	function onEdit(key) {
		setEdit(key);
		$.get({
			url: `/admin/role/${key}`,
			success: data => {
				setCheckedAuthorities(data.authorities);
				form.setFieldsValue({
					departmentId: data.departmentId,
					name: data.name
				});
			}
		});
		$.get({
			url: `/admin/role/node/${key}`,
			success: data => {
				const checkedNodes = [];
				data.forEach(function(row) {
					checkedNodes.push(row.id);
				});
				setCheckedNodes(checkedNodes);
			}
		});
		$.get({
			url: `/admin/role/vehicle/group/${key}`,
			success: groups => {
				setCheckedGroups(groups);
			}
		});
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/role/${key}`,
			success: () => onClose(true),
			fail: error => {
				Modal.error({
					title: '错误',
					content: error.description
				});
			}
		});
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				$.post({
					url: '/admin/role',
					data,
					success: (role) => updateAuthority(role.id)
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit;
				$.put({
					url: '/admin/role',
					data,
					success: () => updateAuthority(edit)
				});
			});
		}
	}

	function updateAuthority(roleId) {
		$.put({
			url: '/admin/role/saveAuthorityAndNode',
			data: {
				roleId,
				nodeIds: checkedNodes || [],
				authorities: (checkedAuthorities || []).filter(key => key !== '权限管理'),
				vehicleGroups: (checkedGroups || []).filter(key => key !== 'group')
			},
			success: () => onClose(true)
		});
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	}

	function onCheckedFuncPriv(checkedKeys) {
		setCheckedNodes(checkedKeys);
	}

	function onCheckDataPriv(checkedKeys) {
		setCheckedAuthorities(checkedKeys);
	}

	function onCheckGroupPriv(checkedKeys) {
		setCheckedGroups(checkedKeys);
	}

	function load(pagination) {
		pagination = pagination || data.pagination;
		setLoading(true);

		$.get({
			url: `/admin/role/page/${pagination.current}/${pagination.pageSize}`,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function toAdd() {
		setEdit(true);
		setCheckedAuthorities([]);
		setCheckedNodes([]);
		setCheckedGroups([]);
		form.resetFields();
	}

	function onSelect(keys) {
		$.get({
			url: '/admin/role/department/' + keys[0],
			success: data => {
				data.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data,
					pagination: {
						...data.pagination,
						total: data.length
					}
				});
			}
		});
	}

	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="角色名称" enterButton onSearch={value => console.log(value)} style={{width: 300}}/>
					<Button type="primary" icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.sider}>
					<Tree
						switcherIcon={<DownOutlined />}
						treeData={departments} 
						className={commonStyles.tree}
						onSelect={onSelect}/>
				</div>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>   
			<Modal
				title="新增角色"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={700}
			>
				<Form className={styles.fo} form={form}>
					<Row gutter={24}>
						<Col span={12}>
							<Form.Item
								label="名称"
								name="name"
								rules={[{ required: true, message: '请输入角色名' }]}
							>
								<Input/>
							</Form.Item>
						</Col>
						<Col span={12}>
							<Form.Item
								label="部门"
								name="departmentId"
								rules={[{ required: true, message: '请选择部门' }]}>
								<TreeSelect treeData={departments}/>
							</Form.Item>
						</Col>
					</Row>
					<div className={styles.row}>
						<div className={styles.wrapper}>
							<div className={styles.wrapperHeader}>功能权限</div>
							<div className={styles.wrapperBody}>
								<Input.Search
									style={{marginBottom: 8}}
									placeholder="输入搜索内容"
									onSearch={value => console.log(value)}
								/>
								{
									nodes
									&&
									<Tree
										checkable
										switcherIcon={<DownOutlined />}
										checkedKeys={checkedNodes}
										treeData={nodes} 
										onCheck={onCheckedFuncPriv}
										className={commonStyles.tree}/>
								}
							</div>
						</div>
						<div className={styles.wrapper}>
							<div className={styles.wrapperHeader}>数据权限</div>
							<div className={styles.wrapperBody}>
								<Input.Search
									style={{marginBottom: 8}}
									placeholder="输入搜索内容"
									onSearch={value => console.log(value)}
								/>
								{
									authorities 
									&&
									<Tree
										checkable
										switcherIcon={<DownOutlined />}
										treeData={authorities} 
										checkedKeys={checkedAuthorities}
										onCheck={onCheckDataPriv}
										className={commonStyles.tree}/>
								}
	
								<Tree
									checkable
									switcherIcon={<DownOutlined />}
									treeData={groups} 
									checkedKeys={checkedGroups}
									onCheck={onCheckGroupPriv}
									className={commonStyles.tree}
								/>
							</div>
						</div>
					</div>
				</Form>
			</Modal> 
		</div>
	);
}