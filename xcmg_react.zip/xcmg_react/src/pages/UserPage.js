/* eslint-disable react/display-name */
import React, {useState, useEffect} from 'react';
import { Table, Space, Input, Button, Modal, Form, Tooltip, TreeSelect, Popconfirm} from 'antd';
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';
import styles from './RolePage.less';
import {
	PlusOutlined
} from '@ant-design/icons';

export default function UserPage() {
	const [form] = Form.useForm();
	const [edit, setEdit] = useState(false);
	const [loading, setLoading] = useState(false);
	const [roles, setRoles] = useState(false);
	const [data, setData] = useState({
		rows: [],
		pagination: {
			total: 0,
			current: 1,
			pageSize: 10
		}
	}); 

	const columns = [{
		title: '序号',
		render: (text,record,index) => `${(data.pagination.current - 1) * data.pagination.pageSize + index + 1}`
	}, {
		title: '用户名',
		dataIndex: 'username'
	}, {
		title: '真实姓名',
		dataIndex: 'realname'
	}, {
		title: '所属角色',
		dataIndex: 'roleName'
	}, {
		title: '状态',
		dataIndex: 'status',
		render: text => text === 'ENABLED' ? '启用' : '禁用'
	}, {
		title: '创建时间',
		dataIndex: 'createTime',
	}, {
		title: '操作',
		render: (text, record) => (
			<Space size="middle">
				<Tooltip title="编辑"><a href="javascript:;" className={styles.icon} onClick={() => onEdit(record.key)}><IconFont type="icon-edit"/></a></Tooltip>
				<Popconfirm title="确认删除？" onConfirm={() => onDelete(record.key)}>
					<Tooltip title="删除">
						<a href="javascript:;" className={styles.icon}><IconFont type="icon-remove"/></a>
					</Tooltip>
				</Popconfirm>
			</Space>
		)
	}];

	useEffect(() => {
		$.get({
			url: '/admin/role/all',
			success: data => {
				const roles = [];
				data.forEach(function(role) {
					roles.push({
						title: role.name,
						value: role.id
					});
				});
				setRoles(roles);
			}
		});
		load();
	}, []);

	function load(pagination, param = '') {
		pagination = pagination || data.pagination;
		setLoading(true);
		$.get({
			url: `/admin/user/page/${pagination.current}/${pagination.pageSize}`,
			data: param ? {param} : null,
			success: data => {
				setLoading(false);
				data.rows.forEach(function(obj) {
					obj.key = obj.id;
				});
				setData({
					rows: data.rows,
					pagination: {
						...pagination,
						total: data.total
					}
				});
			}
		});
	}

	function onTableChange(pagination) {
		load(pagination);
	}

	function onDelete(key) {
		$.delete({
			url: `/admin/user/${key}`,
			success: () => onClose(true)
		});
	}

	function onEdit(key) {
		setEdit(key);
		$.get({
			url: `/admin/user/${key}`,
			success: data => {
				form.setFieldsValue(data);
			}
		});
	}

	function onSave() {
		if (edit === true) {
			form.validateFields().then(data => {
				$.post({
					url: '/admin/user',
					data,
					success: () => onClose(true)
				});
			});
		} else {
			form.validateFields().then(data => {
				data.id = edit;
				$.put({
					url: '/admin/user',
					data,
					success: () => onClose(true)
				});
			});
		}
	}

	function onClose(reload) {
		setEdit(false);
		if (reload) {
			load();
		}
	} 

	function toAdd() {
		setEdit(true);
		form.resetFields();
	}
    
	return (
		<div className={styles.container}>
			<div className={styles.header}>
				<Space>
					<Input.Search placeholder="用户名称" enterButton onSearch={value => load(null, value)} style={{width: 300}}/>
					<Button type="primary" icon={<PlusOutlined />} onClick={toAdd}>新增</Button>
				</Space>
			</div>
			<div className={styles.main}>
				<div className={styles.content}>
					<Table onChange={onTableChange} loading={loading} columns={columns} dataSource={data.rows} pagination={data.pagination} rowSelection={{type: 'checkbox'}} size="small"/>
				</div>
			</div>  
			<Modal
				title="新增用户"
				centered
				visible={edit}
				onOk={onSave}
				onCancel={onClose}
				width={450}
			>
				<Form labelCol={{ span: 5 }} wrapperCol={{ span: 24 }} form={form}>
					<Form.Item
						label="用户名"
						name="username"
						rules={[{ required: true, message: '请输入用户名' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="密码"
						name="password"
						rules={[{ required: true, message: '请输入密码' }]}
					>
						<Input.Password />
					</Form.Item>
					<Form.Item
						label="真实姓名"
						name="realname"
						rules={[{ required: true, message: '请输入真实姓名' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="绑定角色"
						name="roleId"
						rules={[{ required: true, message: '请选择用户角色' }]}
					>
						<TreeSelect treeData={roles}/>
					</Form.Item>
					<Form.Item
						label="联系电话"
						name="phoneNumber"
						rules={[{ required: true, message: '请输入联系电话' }]}
					>
						<Input />
					</Form.Item>
					<Form.Item
						label="备注"
						name="remarks"
					>
						<Input.TextArea />
					</Form.Item>
				</Form>
			</Modal> 
		</div>
	);
}