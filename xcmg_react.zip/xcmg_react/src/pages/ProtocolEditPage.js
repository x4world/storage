/* eslint-disable react/display-name */
/* eslint-disable react/prop-types */
import React, {useState, useContext, useEffect, useRef} from 'react';
import { Row, Col, Table, Space, Input, Button, Form, Modal, Popconfirm, Select, Radio} from 'antd';
import styles from './TemplateEditPage.less';
const EditableContext = React.createContext();
import IconFont from '../utils/IconFont';
import $ from '../utils/CommonUtil';

const typeMap = {
	CONFIG: 1,
	SET: 2,
	DISPLAY: 3,
	CALIBRATION: 4
};

const typeTextMap = {
	CONFIG: '配置参数',
	SET: '设置参数',
	DISPLAY: '显示参数',
	CALIBRATION: '标定参数'
};

const EditableRow = ({ ...props }) => {
	const [form] = Form.useForm();
	return (
		<Form form={form} component={false}>
			<EditableContext.Provider value={form}>
				<tr {...props} />
			</EditableContext.Provider>
		</Form>
	);
};

const EditableCell = ({
	editable,
	children,
	dataIndex,
	record,
	handleSave,
	...restProps
}) => {
	const form = useContext(EditableContext);
	const inputRef = useRef();
	const [editing, setEditing] = useState(false);
	const save = async () => {
		try {
			const values = await form.validateFields();
			toggleEdit();
			handleSave({ ...record, ...values });
		} catch (errInfo) {
			console.log('Save failed:', errInfo);
		}
	};

	useEffect(() => {
		if (editing) {
			inputRef.current.focus();
		}
	}, [editing]);

	const toggleEdit = () => {
		setEditing(!editing);
		form.setFieldsValue({ [dataIndex]: record[dataIndex] });
	};

	let childNode = children;
	if (editable) {
		childNode = editing  ? (
			<Form.Item
				style={{margin: 0}}
				name={dataIndex}>
				{
					dataIndex === 'type' 
						?
						<Select ref={inputRef} onBlur={save} >
							<Select.Option value="CONFIG">配置参数</Select.Option>
							<Select.Option value="SET">设置参数</Select.Option>
							<Select.Option value="DISPLAY">显示参数</Select.Option>
							<Select.Option value="CALIBRATION">标定参数</Select.Option>
						</Select>
						:
						dataIndex === 'dataType'
							?
							<Select ref={inputRef} onBlur={save} showSearch>
								<Select.Option value="BOOL">BOOL</Select.Option>
								<Select.Option value="BYTE">BYTE</Select.Option>
								<Select.Option value="WORD">WORD</Select.Option>
								<Select.Option value="DWORD">DWORD</Select.Option>
								<Select.Option value="LWORD">LWORD</Select.Option>
								<Select.Option value="SINT">SINT</Select.Option>
								<Select.Option value="USSINT">USINT</Select.Option>
								<Select.Option value="INT">INT</Select.Option>
								<Select.Option value="UINT">UINT</Select.Option>
								<Select.Option value="DINT">DINT</Select.Option>
								<Select.Option value="LINT">LINT</Select.Option>
								<Select.Option value="REAL">REAL</Select.Option>
								<Select.Option value="LREAL">LREAL</Select.Option>
								<Select.Option value="STRING">STRING</Select.Option>
								<Select.Option value="TIME">TIME</Select.Option>
								<Select.Option value="TIME_OF_DAY">TIME_OF_DAY</Select.Option>
								<Select.Option value="DATE">DATE</Select.Option>
								<Select.Option value="DATE_AND_TIME">DATE_AND_TIME</Select.Option>
							</Select>
							:
							(dataIndex === 'dataUnit' || dataIndex === 'physicalUnit')
								?
								<Select ref={inputRef} onBlur={save} >
									<Select.Option value="°">°</Select.Option>
									<Select.Option value="m">m</Select.Option>
									<Select.Option value="s">s</Select.Option>
									<Select.Option value="mA">mA</Select.Option>
									<Select.Option value="%">%</Select.Option>
									<Select.Option value="V">V</Select.Option>
									<Select.Option value="AD值">AD值</Select.Option>
									<Select.Option value="T/F">T/F</Select.Option>
									<Select.Option value="1">1</Select.Option>
								</Select>
								:
								<Input ref={inputRef} onPressEnter={save} onBlur={save} />
				}
			</Form.Item>
		) : (
			<div className="editable-cell-value-wrap" style={{ height: 24 }} onClick={toggleEdit}>
				{children}
			</div>
		);
	}
	
	return <td {...restProps}>{childNode}</td>;
};

export default function ProtocolEditPage(props) {
	const [form] = Form.useForm();
	const [pages, setPages] = useState([]);
	const [filter, setFilter] = useState('ALL');
	const keyRef = useRef(0);
	const columns = [{
		title: '参数名称',
		dataIndex: 'name',
		width: 190,
		editable: true
	}, {
		title: '地址',
		dataIndex: 'address',
		editable: true,
		width: 80
	}, {
		title: '参数类型',
		dataIndex: 'type',
		editable: true,
		width: 120,
		render: text => typeTextMap[text]
	}, {
		title: '传输数据类型',
		dataIndex: 'dataType',
		editable: true,
		width: 120
	}, {
		title: '传输数据范围',
		dataIndex: 'dataRange',
		editable: true,
		width: 140
	}, {
		title: '传输数据分辨率',
		dataIndex: 'dataResolution',
		editable: true,
		width: 120
	}, {
		title: '传输数据单位',
		dataIndex: 'dataUnit',
		editable: true,
		width: 120
	}, {
		title: '实际物理量单位',
		dataIndex: 'physicalUnit',
		editable: true,
		width: 120
	}, {
		title: '比例系数',
		dataIndex: 'dataRatio',
		editable: true,
		width: 100
	}, {
		title: '偏移量',
		dataIndex: 'offset',
		editable: true,
		width: 100
	}, {
		title: '备注',
		dataIndex: 'remarks',
		editable: true
	}, {
		title: '操作',
		width: 60,
		align: 'center',
		render: (text, record) => (
			<Popconfirm title="确认删除？">
				<a href="javascript:;" className={styles.icon} onClick={() => onRowDelete(record.key)}><IconFont type="icon-remove"/></a>
			</Popconfirm>
		)
	}];

	useEffect(() => {
		if (props.pid) {
			$.get({
				url: '/admin/vehicle/parameter/table/details/' + props.pid,
				success: data => {
					data.pages.forEach(function(page) {
						page.items.forEach(function(item) {
							item.key = keyRef.current++;
						});
					});
					setPages(data.pages);
					form.setFieldsValue(data);
				}
			});
		} else {
			onAddPage();
		}
	}, []);

	function onFinish(formData) {
		const newPages = [];
		pages.forEach(function(page) {
			const newPage = {...page, items: []};
			page.items.forEach(function(item) {
				if (item.name) {
					const newItem = {...item};
					newItem.pageCode = page.code;
					newItem.type = typeMap[item.type];
					newPage.items.push(newItem);
				}
			});
			newPages.push(newPage);
		});
		formData.pages = newPages;

		if (props.pid) {
			formData.id = props.pid;
			$.put({
				url: '/admin/vehicle/parameter/table/save',
				data: formData,
				success: onSave,
				fail: onSaveFail
			});
		} else {
			$.post({
				url: '/admin/vehicle/parameter/table/save',
				data: formData,
				success: onSave,
				fail: onSaveFail
			});
		}
	}
	
	function onRowDelete(key) {
		for (let page of pages) {
			let index = page.items.findIndex(item => item.key === key);
			if (index !== -1) {
				const items= [...page.items];
				items.splice(index, 1);
				page.items = items;
				setPages(pages);
				return;
			}
		}
	}

	function onSave() {
		props.onRet();
	}

	function onSaveFail(error) {
		Modal.error({
			title: '错误',
			content: error.description
		});
	}

	function onAddItem(page) {
		if (page.items.length < 8) {
			const items = [...page.items];
			items.push(getNewItem());
			page.items = items;
			setPages(pages);
		} else {
			Modal.error({
				title: '错误',
				content: '每页不能超过8个地址'
			});
		}
	}

	function onPageChange(page, code) {
		page.code = code;
		setPages(pages);
	}

	function onPageNameChange(page, name) {
		page.name = name;
		setPages(pages);
	}

	function getNewItem() {
		const item = {key: keyRef.current++};
		if (filter !== 'ALL') {
			item.type = filter;
		}
		return item;
	}

	function onAddPage() {
		const page = {code: '', name: '', items: [getNewItem()]};
		pages.push(page);
		setPages(pages);
	}

	function handleSave(row) {
		for (let page of pages) {
			for (let item of page.items) {
				if (item.key === row.key) {
					for (let m in row) {
						item[m] = row[m];
					}
					setPages(pages);
					return;
				}
			}
		}
	}

	function onFilterChange(e) {
		setFilter(e.target.value);
	}

	function onPageRemove(index) {
		pages.splice(index, 1);
		setPages(pages);
	}

	const columns2 = columns.map((col) => {
		if (!col.editable) {
			return col;
		}
	
		return {
			...col,
			onCell: record => ({
				record,
				editable: col.editable,
				dataIndex: col.dataIndex,
				title: col.title,
				editing: record.editing,
				handleSave
			})
		};
	});

	function showFilter(items) {
		if (filter === 'ALL') {
			return items;
		} else {
			return items.filter(item => item.type === filter);
		}
	}

	const components={body: {row: EditableRow, cell: EditableCell}};
	return (
		<div>
			<Form className={styles.block} form={form} onFinish={onFinish} style={{paddingBottom: 0}}>
				<Row>
					<Col>
						<Form.Item
							name='name'
							label='协议名称'
							rules={[{ required: true, message: '请输入模板名称' }]}>
							<Input style={{width: 200}}/>
						</Form.Item>
					</Col>
					<Col offset={1}>
						<Form.Item
							name='version'
							label='版本号'
							rules={[{ required: true, message: '请输入版本号' }]}>
							<Input placeholder="1.0" />
						</Form.Item>
					</Col>
					<Col offset={1}>
						<Space>
							<Button type='primary' style={{width: 100}} htmlType='submit'>保存</Button>
							<Button style={{width: 100}} onClick={() => props.onRet()}>返回</Button>
						</Space>
					</Col>
				</Row>
			</Form>
			<div style={{margin: '12px 0'}}>
				<Radio.Group buttonStyle='solid' value={filter} onChange={onFilterChange}>
					<Radio.Button value="ALL">全部</Radio.Button>
					<Radio.Button value='CONFIG'>配置参数</Radio.Button>
					<Radio.Button value='SET'>设置参数</Radio.Button>
					<Radio.Button value='DISPLAY'>显示参数</Radio.Button>
					<Radio.Button value='CALIBRATION'>标定参数</Radio.Button>
				</Radio.Group>
			</div>
			{
				pages.map((page, index) => {
					const items = showFilter(page.items);
					return (
						items.length > 0
							?
							<div key={index} className={styles.block} style={{marginBottom: 20}}>
								<Table title={
									() => 
										<div className={styles.titleWrapper}>
											<div>页码：<Input style={{width: 80, marginRight: 16}} value={page.code} onChange={e => onPageChange(page, e.target.value)}/>名称：<Input style={{width: 200}} value={page.name} onChange={e => onPageNameChange(page, e.target.value)}/></div>
											<div>
												<a href="javascript:;" className={styles.icon} style={{marginRight: 10}} onClick={() => onAddItem(page)}>
													<IconFont type="icon-plus"/>
												</a>
												<Popconfirm title="确认删除本页？" onConfirm={() => onPageRemove(index)}>
													<a href="javascript:;" className={styles.icon} style={{marginRight: 10}}>
														<IconFont type="icon-remove"/>
													</a>
												</Popconfirm>
											</div>
										</div>
								} bordered pagination={false} components={components} columns={columns2} dataSource={items} size='small'/>
							</div>
							:
							null
					);
				})
			}
			{filter === 'ALL' && <div style={{textAlign: 'center', marginTop: 10}}><a href="javascript:;" style={{color: '#007EED'}}  onClick={onAddPage}>新增页</a></div>}
		</div>
	);
}