/* eslint-disable react/display-name */
import React from 'react';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom';
import {ConfigProvider} from 'antd';
import MainPage from './pages/MainPage';
import LoginPage from './pages/LoginPage';
import RegPage from './pages/RegPage';
import locale from 'antd/es/locale/zh_CN';

function App() {
	return (
		<Router>
			<Switch>
				<Route path="/" exact component={MainPage}></Route>
				<Route path="/login" component={LoginPage}></Route>
				<Route path="/main" component={MainPage}></Route>
				<Route path="/reg" component={RegPage}></Route>
			</Switch>
		</Router>
	);
}

export default () => (
	<ConfigProvider locale={locale}>
		<App />
	</ConfigProvider>
);