'use strict';
const send = require('koa-send');
const normalize = require('upath').normalizeSafe;
const path = require('path');

module.exports = function serve(opts) {

	let options = opts || {};
	options.root = path.resolve(options.rootDir || process.cwd());
	options.index = options.index || 'index.html';
	const rootPath = normalize(options.rootPath ? options.rootPath + '/' : '/');

	return async (ctx, next) => {
		if (ctx.method !== 'HEAD' && ctx.method !== 'GET')
			return await next();

		let path = ctx.path;

		if (path + '/' === rootPath)
			return ctx.redirect(rootPath);

		if (path.indexOf(rootPath) !== 0)
			return await next();

		path = normalize(path.replace(rootPath, '/'));

		try {
			await send(ctx, path, options);
		} catch (e) {
			if (options.notFoundFile)
				await send(ctx, options.notFoundFile, options);
			else {
				await next();
			}
		}
	};
};