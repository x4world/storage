const Koa = require('koa');
const app = new Koa();

const serve = require('./common/StaticServer');
app.use(serve({ rootDir: './public', rootPath: '/' }));
app.use(require('./router'));

app.listen(18888);
console.log('server listen on 18888');