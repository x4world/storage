# MP3 Encoder

Dummy app to test electron using an external process, coffee-script
and backbone on both windows and OSX.
