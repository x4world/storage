# Service Worker Sample: Mock Response

A sample demonstrates basic service worker registeration with file scheme, and
the service worker's fetch handler.

## Screenshot

![screenshot](/service-worker/mock-response/screenshot/register.png)
![screenshot](/service-worker/mock-response/screenshot/response.png)
