# Desktop Capturer

A sample app allows you to choose which screen or window to be captured with
`getUserMedia` API.

## APIs

[desktopCapturer](https://github.com/atom/electron/blob/master/docs/api/desktop-capturer.md)

## Screenshot

![screenshot](https://cloud.githubusercontent.com/assets/2557445/10268326/993e4f9a-6ae7-11e5-8fd1-a24b9800b9ce.gif)
