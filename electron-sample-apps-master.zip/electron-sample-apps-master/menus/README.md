# Menus

This is a basic demo that demonstrates the flexibility of electron's Menus
API, there aree three menus bound to three areas in the page.


## APIs

* [Menu](https://github.com/atom/electron/blob/master/docs/api/menu.md)
* [MenuItem](https://github.com/atom/electron/blob/master/docs/api/menu-item.md)
