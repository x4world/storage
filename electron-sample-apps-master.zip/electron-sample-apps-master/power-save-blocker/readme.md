# Power-save-blocker

A tray sample reprevents the display from sleep.

## APIs

[power-save-blocker](https://github.com/electron/electron/blob/master/docs/api/power-save-blocker.md)

## Screenshot

![screenshot](/power-save-blocker/screenshot/screenshot.png)
