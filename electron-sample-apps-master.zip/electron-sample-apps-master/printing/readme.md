# Printing Sample

A sample app demonstrates printing APIs usage.


## APIs

* [webContents.print](https://github.com/electron/electron/blob/master/docs/api/web-contents.md#contentsprintoptions)

* [webContents.printToPDF](https://github.com/electron/electron/blob/master/docs/api/web-contents.md#contentsprinttopdfoptions-callback)

## Screenshot

![screenshot](/printing/screenshot/screenshot.png)
