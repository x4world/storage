# Cookies

A sample app allows you to manipulate your cookies data using [cookies][1] API.

## APIs

[Session.cookies][1]

## Screenshot

![screenshot](/cookies/screenshot/screenshot.png)

[1]: https://github.com/electron/electron/blob/master/docs/api/session.md#sescookies
